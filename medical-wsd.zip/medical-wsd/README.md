# Cross-Specialty Generalization of Medical WSD

Bridging Synthetic and Real Clinical Text for Medical Abbreviation Disambiguation.

## ⚠️ Environment constraints (read first)

This build ran in a sandboxed environment whose network access is limited to package
registries (PyPI, npm, GitHub, crates.io, Ubuntu mirrors). It has **no access** to:

- **Hugging Face Hub** — where MeDAL and pretrained biomedical transformers
  (PubMedBERT, BioBERT, ClinicalBERT, SciBERT) are hosted
- **PhysioNet / MIMIC** — also requires credentialed access unavailable here
- **Kaggle / Zenodo** — alternate dataset mirrors

Consequences, applied consistently everywhere in this repo (code, results, dashboard):

| Spec requirement | What actually happened |
|---|---|
| MeDAL as source domain | Replaced with a **synthetic**, template-generated dataset (`src/data/synthetic_generator.py`), seeded from a curated real medical abbreviation→sense dictionary. Every record is tagged `domain: "synthetic"`, never `clinical`. |
| Real clinical target domain (MIMIC-style) | **Not available.** The domain-gap experiment (RQ1) is implemented as an interface (`src/domain_shift/pending_real_clinical.py`) and marked `PENDING` everywhere, including in the dashboard. Supplying real clinical records in the standardized schema makes it runnable immediately, no other code changes needed. |
| Pretrained biomedical transformer (Model 3) | **Not available** (can't download weights). Substituted with a small Transformer encoder **trained from scratch** on the synthetic data only (`src/models/small_transformer.py`), always labeled `SmallTransformer-Scratch` — never confused with a real pretrained biomedical LM. |
| Cross-specialty transfer (RQ2) | Run for real on synthetic data with procedurally-assigned (but semantically real) specialty labels. A genuine limitation was found and is reported, not hidden: specialty is nearly a deterministic function of sense in this dictionary, so most transfer cells are structurally zero-shot. See the Cross-Specialty dashboard page. |
| Data-efficient adaptation (RQ3) | Run for real using a held-out specialty (Neurology) as a **proxy** target domain, since no real clinical target exists. Clearly labeled as a proxy, not the real experiment. |

Nothing in this repo claims synthetic data is clinical, fabricates metrics, or presents a
placeholder as a completed experiment without saying so.

## Install

```bash
pip install -r requirements.txt
```

## Run the full pipeline (data → training → all experiments → figures)

```bash
PYTHONPATH=. python3 run.py
```

This regenerates the synthetic dataset, trains all 3 models, evaluates them, and runs every
experiment, saving results under `results/` and figures under `paper/figures/`. Takes under a
minute on CPU. Models are also pickled to `models/` so the dashboard never retrains on startup.

## Launch the dashboard

```bash
streamlit run dashboard/app.py
```

Reads only from `results/` and `models/` — it does not retrain anything.

## Project structure

```
medical-wsd/
├── data/processed/          # synthetic dataset (raw + preprocessed jsonl)
├── src/
│   ├── data/                 # abbreviation dictionary, synthetic generator, EDA
│   ├── preprocessing/        # context windows, cleaning, leakage check
│   ├── models/                # Majority, TF-IDF+LogReg, SmallTransformer-Scratch, live inference
│   ├── evaluation/            # metrics, calibration, error analysis
│   ├── domain_shift/          # pending real-clinical experiment + data-efficiency proxy experiment
│   ├── specialty/             # cross-specialty transfer experiment
│   └── context_analysis/      # context-window + perturbation experiments
├── models/                    # pickled trained models (tfidf_logreg, majority)
├── results/                   # all experiment outputs, organized by type
├── paper/figures/             # publication-ready PNG figures
├── dashboard/app.py           # 9-page Streamlit research dashboard
├── configs/config.json
└── run.py                     # orchestrates the entire pipeline end-to-end
```

## Reproducibility

- Fixed random seed (42) everywhere: data generation, split, and model training.
- `configs/config.json` holds every experiment's hyperparameters.
- All results are re-derivable by running `run.py`; the dashboard is a pure reader.

## Known limitations / what a real deployment would need

1. A real, credentialed, de-identified clinical corpus (e.g. MIMIC-III/IV notes) to run the
   actual domain-gap and cross-specialty experiments the spec intends.
2. Network access to Hugging Face Hub to fine-tune an actual pretrained biomedical transformer
   instead of the from-scratch substitute.
3. The synthetic generator's specialty labels are a deterministic function of sense for most
   abbreviations, which structurally limits how informative the current cross-specialty matrix
   can be — a real dataset with specialty-independent sense distributions would fix this.
4. This is a research/demo system: no clinical decision-making claims are made, and the
   dashboard explicitly avoids presenting the live WSD demo as a diagnostic tool.
