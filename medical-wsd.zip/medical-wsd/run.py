"""
End-to-end experiment runner.

Usage:
    PYTHONPATH=. python3 run.py
"""
import json
import time
from pathlib import Path

import numpy as np

from src.data.synthetic_generator import generate_dataset, save_dataset
from src.preprocessing.pipeline import run as run_preprocessing
from src.data.eda import run as run_eda

from src.models.majority_baseline import MajorityBaseline
from src.models.tfidf_logreg import TfidfLogRegWSD
from src.models.small_transformer import SmallTransformerWSD

from src.evaluation.metrics import (
    compute_core_metrics, per_abbreviation_performance,
    expected_calibration_error, brier_score, high_confidence_error_rate,
    coverage_accuracy_curve,
)
from src.evaluation.error_analysis import run_error_analysis
from src.specialty.transfer_experiment import run_transfer_experiment
from src.domain_shift.data_efficiency import run_data_efficiency
from src.domain_shift.pending_real_clinical import PENDING_STATUS
from src.context_analysis.context_experiment import run_context_experiment, run_perturbation_experiment

from sklearn.metrics import confusion_matrix
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns


def ensure_dirs():
    for d in ["results/metrics", "results/predictions", "results/calibration", "results/domain_shift",
              "results/specialty_transfer", "results/data_efficiency", "results/context_analysis",
              "results/confusion_matrices", "results/errors", "paper/figures", "models"]:
        Path(d).mkdir(parents=True, exist_ok=True)


def save_json(obj, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        json.dump(obj, f, indent=2)


def load_jsonl(path):
    return [json.loads(l) for l in open(path)]


def evaluate_model(name, model, train, test, context_field, max_classes):
    preds, confs, prob_dists = model.predict(test)
    labels = [r["label"] for r in test]
    correct = [p == l for p, l in zip(preds, labels)]

    core = compute_core_metrics(labels, preds)
    per_abbr = per_abbreviation_performance(test, preds)
    ece, bins = expected_calibration_error(confs, correct)
    brier = brier_score(prob_dists, labels, max_classes)
    hce_rate, hce_n = high_confidence_error_rate(confs, correct, threshold=0.8)
    cm = confusion_matrix(labels, preds).tolist()
    cov_acc = coverage_accuracy_curve(confs, correct)

    result = {
        "model": name,
        "context_field": context_field,
        **core,
        "ece": ece,
        "brier_score": brier,
        "avg_confidence": float(np.mean(confs)),
        "avg_confidence_correct": float(np.mean([c for c, ok in zip(confs, correct) if ok])) if any(correct) else None,
        "avg_confidence_incorrect": float(np.mean([c for c, ok in zip(confs, correct) if not ok])) if not all(correct) else None,
        "high_confidence_error_rate": hce_rate,
        "high_confidence_n": hce_n,
    }

    save_json(result, f"results/metrics/{name}_test_metrics.json")
    save_json(per_abbr, f"results/metrics/{name}_per_abbreviation.json")
    save_json({"bins": bins, "ece": ece}, f"results/calibration/{name}_reliability.json")
    save_json(cov_acc, f"results/calibration/{name}_coverage_accuracy.json")
    save_json(cm, f"results/confusion_matrices/{name}_confusion_matrix.json")

    predictions_out = []
    for r, p, c, pd_ in zip(test, preds, confs, prob_dists):
        predictions_out.append({
            "id": r["id"], "abbreviation": r["abbreviation"], "sentence": r["sentence"],
            "context_3": r["context_3"], "true_label": r["label"], "true_sense": r["sense"],
            "predicted_label": p, "predicted_sense": r["candidate_senses"][p] if p < len(r["candidate_senses"]) else "UNKNOWN",
            "confidence": c, "correct": bool(p == r["label"]), "domain": r["domain"],
            "specialty": r["specialty"], "context_length": r["context_2_length"], "model": name,
        })
    with open(f"results/predictions/{name}_predictions.jsonl", "w") as f:
        for row in predictions_out:
            f.write(json.dumps(row) + "\n")

    return result, preds, confs


def plot_model_comparison(results):
    names = [r["model"] for r in results]
    fig, axes = plt.subplots(1, 3, figsize=(14, 4.5))
    for ax, metric in zip(axes, ["accuracy", "macro_f1", "weighted_f1"]):
        vals = [r[metric] for r in results]
        ax.bar(names, vals, color=["#a0a0a0", "#3b6fa0", "#5b9279"])
        ax.set_title(metric.replace("_", " ").title())
        ax.set_ylim(0, 1)
        for i, v in enumerate(vals):
            ax.text(i, v + 0.02, f"{v:.2f}", ha="center")
    plt.tight_layout()
    fig.savefig("paper/figures/model_comparison.png", dpi=150)
    plt.close(fig)


def plot_reliability_diagrams(all_bins):
    fig, axes = plt.subplots(1, len(all_bins), figsize=(5 * len(all_bins), 4.5))
    if len(all_bins) == 1:
        axes = [axes]
    for ax, (name, bins) in zip(axes, all_bins.items()):
        xs = [(b["bin_lo"] + b["bin_hi"]) / 2 for b in bins if b["count"] > 0]
        accs = [b["avg_acc"] for b in bins if b["count"] > 0]
        confs = [b["avg_conf"] for b in bins if b["count"] > 0]
        ax.plot([0, 1], [0, 1], "k--", alpha=0.4, label="Perfect calibration")
        ax.bar(xs, accs, width=0.08, alpha=0.7, color="#3b6fa0", label="Accuracy")
        ax.scatter(confs, accs, color="#a05b5b", zorder=5, label="Conf vs Acc")
        ax.set_title(f"Reliability Diagram: {name}")
        ax.set_xlabel("Confidence")
        ax.set_ylabel("Accuracy")
        ax.legend(fontsize=8)
    plt.tight_layout()
    fig.savefig("paper/figures/reliability_diagrams.png", dpi=150)
    plt.close(fig)


def plot_confusion_matrix(cm, abbr_name, model_name, labels):
    fig, ax = plt.subplots(figsize=(4, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=labels, yticklabels=labels, ax=ax, cbar=False)
    ax.set_title(f"{model_name}")
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    plt.tight_layout()
    fig.savefig(f"paper/figures/confusion_matrix_{model_name}.png", dpi=150)
    plt.close(fig)


def plot_specialty_heatmap(matrix_acc):
    specialties = list(matrix_acc.keys())
    data = np.array([[matrix_acc[s1][s2] if matrix_acc[s1][s2] is not None else np.nan for s2 in specialties] for s1 in specialties])
    fig, ax = plt.subplots(figsize=(7, 6))
    sns.heatmap(data, annot=True, fmt=".2f", cmap="RdYlGn", vmin=0, vmax=1,
                xticklabels=specialties, yticklabels=specialties, ax=ax)
    ax.set_xlabel("Test Specialty")
    ax.set_ylabel("Train Specialty")
    ax.set_title("Cross-Specialty Transfer (Accuracy) — Synthetic Data")
    plt.tight_layout()
    fig.savefig("paper/figures/specialty_heatmap.png", dpi=150)
    plt.close(fig)


def plot_data_efficiency(results):
    if "results" not in results or not results["results"]:
        return
    pcts = [r["target_data_percentage"] * 100 for r in results["results"]]
    acc = [r["accuracy"] for r in results["results"]]
    f1 = [r["macro_f1"] for r in results["results"]]
    ece = [r["ece"] for r in results["results"]]
    fig, axes = plt.subplots(1, 2, figsize=(11, 4.5))
    axes[0].plot(pcts, acc, "o-", label="Accuracy", color="#3b6fa0")
    axes[0].plot(pcts, f1, "s-", label="Macro F1", color="#5b9279")
    axes[0].set_xlabel("Target-domain data used (%)")
    axes[0].set_title(f"Performance vs Target Data ({results['target_specialty']})")
    axes[0].legend()
    axes[1].plot(pcts, ece, "o-", color="#a05b5b")
    axes[1].set_xlabel("Target-domain data used (%)")
    axes[1].set_title("Calibration (ECE) vs Target Data")
    plt.tight_layout()
    fig.savefig("paper/figures/data_efficiency_curve.png", dpi=150)
    plt.close(fig)


def plot_context_sensitivity(results):
    labels = [r["label"] for r in results]
    acc = [r["accuracy"] for r in results]
    conf = [r["avg_confidence"] for r in results]
    fig, ax = plt.subplots(figsize=(8, 4.5))
    ax.plot(labels, acc, "o-", label="Accuracy", color="#3b6fa0")
    ax.plot(labels, conf, "s-", label="Avg Confidence", color="#a05b5b")
    ax.set_title("Context Sensitivity")
    ax.set_ylabel("Score")
    ax.legend()
    plt.tight_layout()
    fig.savefig("paper/figures/context_sensitivity_curve.png", dpi=150)
    plt.close(fig)


def plot_error_categories(cat_counts):
    fig, ax = plt.subplots(figsize=(9, 5))
    items = sorted(cat_counts.items(), key=lambda x: -x[1])
    names = [i[0] for i in items]
    vals = [i[1] for i in items]
    ax.barh(names, vals, color="#a05b5b")
    ax.set_title("Error Category Distribution (Small Transformer, Test Set)")
    ax.invert_yaxis()
    plt.tight_layout()
    fig.savefig("paper/figures/error_category_chart.png", dpi=150)
    plt.close(fig)


def main():
    t_start = time.time()
    ensure_dirs()
    print("=" * 70)
    print("PHASE 1: Data generation + preprocessing")
    print("=" * 70)
    records = generate_dataset(n_per_sense=40)
    save_dataset(records, "data/processed/synthetic_wsd.jsonl")
    processed, leakage = run_preprocessing("data/processed/synthetic_wsd.jsonl",
                                            "data/processed/synthetic_wsd_preprocessed.jsonl")
    print(f"Generated {len(processed)} records. Leakage check: {leakage}")

    eda_stats = run_eda()
    print(f"EDA complete: {eda_stats['total_samples']} samples, "
          f"{eda_stats['unique_abbreviations']} abbreviations, {eda_stats['unique_senses']} senses")

    train = [r for r in processed if r["split"] == "train"]
    val = [r for r in processed if r["split"] == "val"]
    test = [r for r in processed if r["split"] == "test"]
    max_classes = max(r["num_candidates"] for r in processed)

    print("\n" + "=" * 70)
    print("PHASE 2-3: Training Model 1 (Majority), Model 2 (TF-IDF+LogReg), Model 3 (SmallTransformer-Scratch)")
    print("=" * 70)

    m1 = MajorityBaseline().fit(train)
    m2 = TfidfLogRegWSD(context_field="context_2").fit(train)
    m3 = SmallTransformerWSD(context_field="context_3", epochs=15, batch_size=32).fit(train, val_records=val, verbose=False)
    save_json(m3.history, "results/metrics/small_transformer_training_history.json")

    import pickle
    with open("models/tfidf_logreg.pkl", "wb") as f:
        pickle.dump(m2, f)
    with open("models/majority_baseline.pkl", "wb") as f:
        pickle.dump(m1, f)
    print("Saved models/tfidf_logreg.pkl and models/majority_baseline.pkl for dashboard reuse (no retraining on startup).")

    print("\n" + "=" * 70)
    print("PHASE 4: Evaluation on synthetic in-domain test set (Experiment 1)")
    print("=" * 70)

    results_all = []
    bins_all = {}
    for name, model, ctx in [
        ("majority_baseline", m1, "context_1"),
        ("tfidf_logreg", m2, "context_2"),
        ("small_transformer_scratch", m3, "context_3"),
    ]:
        res, preds, confs = evaluate_model(name, model, train, test, ctx, max_classes)
        results_all.append(res)
        bins_all[name] = json.load(open(f"results/calibration/{name}_reliability.json"))["bins"]
        print(f"  {name:28s} acc={res['accuracy']:.3f}  macroF1={res['macro_f1']:.3f}  ECE={res['ece']:.3f}")
        if name == "small_transformer_scratch":
            best_preds, best_confs = preds, confs

    save_json({"models": results_all}, "results/metrics/model_comparison.json")
    plot_model_comparison(results_all)
    plot_reliability_diagrams(bins_all)

    cm = np.array(json.load(open("results/confusion_matrices/tfidf_logreg_confusion_matrix.json")))
    # (per-abbreviation confusion matrices are more meaningful than a global one across
    # different label spaces; save a per-abbreviation set for the top 3 most ambiguous)
    from collections import Counter
    abbr_counts = Counter(r["abbreviation"] for r in test)
    top_abbrs = [a for a, _ in abbr_counts.most_common(3)]
    for abbr in top_abbrs:
        sub_test = [r for r in test if r["abbreviation"] == abbr]
        preds_sub, _, _ = m2.predict(sub_test)
        labels_sub = [r["label"] for r in sub_test]
        senses = sub_test[0]["candidate_senses"]
        cm_abbr = confusion_matrix(labels_sub, preds_sub, labels=list(range(len(senses))))
        plot_confusion_matrix(cm_abbr, abbr, f"tfidf_logreg_{abbr}", senses)

    print("\n" + "=" * 70)
    print("PHASE 6 (marked pending): Domain Generalization — real clinical text unavailable")
    print("=" * 70)
    save_json(PENDING_STATUS, "results/domain_shift/synthetic_to_clinical_PENDING.json")
    print(f"  status: {PENDING_STATUS['status']} — {PENDING_STATUS['reason'][:80]}...")

    print("\n" + "=" * 70)
    print("PHASE 7: Cross-Specialty Transfer (Experiment 3, synthetic data)")
    print("=" * 70)
    specialty_results = run_transfer_experiment(train, test)
    save_json(specialty_results, "results/specialty_transfer/cross_specialty_results.json")
    plot_specialty_heatmap(specialty_results["matrix_accuracy"])
    print(f"  avg same-specialty acc={specialty_results['summary']['avg_same_specialty_accuracy']}")
    print(f"  avg cross-specialty acc={specialty_results['summary']['avg_cross_specialty_accuracy']}")

    print("\n" + "=" * 70)
    print("PHASE 9: Data-Efficient Adaptation (Experiment 4, proxy target = Neurology)")
    print("=" * 70)
    data_eff_results = run_data_efficiency(train, test, target_specialty="Neurology")
    save_json(data_eff_results, "results/data_efficiency/neurology_proxy_target.json")
    plot_data_efficiency(data_eff_results)
    if "results" in data_eff_results:
        for r in data_eff_results["results"]:
            print(f"  target%={r['target_data_percentage']*100:5.1f}  acc={r['accuracy']:.3f}  ECE={r['ece']:.3f}")

    print("\n" + "=" * 70)
    print("PHASE 10: Context Sensitivity (Experiment 5)")
    print("=" * 70)
    context_results = run_context_experiment(train, test)
    save_json(context_results, "results/context_analysis/context_sensitivity.json")
    plot_context_sensitivity(context_results)
    for r in context_results:
        print(f"  {r['label']:20s} acc={r['accuracy']:.3f}  conf={r['avg_confidence']:.3f}")

    perturb_results = run_perturbation_experiment(train, test)
    save_json(perturb_results, "results/context_analysis/perturbation_results.json")
    for r in perturb_results:
        print(f"  perturb={r['perturbation']:20s} acc={r['accuracy']:.3f}")

    print("\n" + "=" * 70)
    print("PHASE 11: Error Analysis (Experiment 6/7/18, small transformer predictions)")
    print("=" * 70)
    error_results = run_error_analysis(train, test, best_preds, best_confs)
    save_json(error_results, "results/errors/error_analysis.json")
    plot_error_categories(error_results["category_counts"])
    print(f"  {error_results['num_errors']} errors out of {error_results['num_total']} "
          f"({error_results['error_rate']*100:.1f}%)")

    print("\n" + "=" * 70)
    print(f"DONE in {time.time() - t_start:.1f}s")
    print("=" * 70)


if __name__ == "__main__":
    main()
