"""
Model 3 - Small Transformer (trained FROM SCRATCH on synthetic data only).

IMPORTANT / HONESTY NOTE: The project spec calls for a pretrained
biomedical transformer (PubMedBERT / BioBERT / ClinicalBERT / SciBERT).
This sandbox has no network access to Hugging Face Hub, so those weights
cannot be downloaded. This class is a substitute: a small Transformer
encoder with randomly-initialized weights, trained end-to-end only on
this project's synthetic dataset. It is a real, small neural network
that is genuinely trained and evaluated - it is NOT a pretrained
biomedical language model, and every result/table/dashboard label
referencing it should say "SmallTransformer-Scratch", never PubMedBERT
or similar.
"""
import re
import random
from collections import defaultdict, Counter

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

torch.manual_seed(42)
random.seed(42)


def tokenize(text):
    text = text.replace("[ABBR]", " [ABBR] ").replace("[/ABBR]", " [/ABBR] ")
    return re.findall(r"[A-Za-z]+|\[ABBR\]|\[/ABBR\]|\d+", text.lower())


class Vocab:
    def __init__(self, min_freq=1):
        self.stoi = {"<pad>": 0, "<unk>": 1}
        self.min_freq = min_freq

    def build(self, texts):
        counter = Counter()
        for t in texts:
            counter.update(tokenize(t))
        for tok, freq in counter.items():
            if freq >= self.min_freq and tok not in self.stoi:
                self.stoi[tok] = len(self.stoi)
        return self

    def encode(self, text, max_len):
        ids = [self.stoi.get(tok, 1) for tok in tokenize(text)][:max_len]
        ids = ids + [0] * (max_len - len(ids))
        return ids

    def __len__(self):
        return len(self.stoi)


class SmallTransformerModel(nn.Module):
    def __init__(self, vocab_size, num_abbrs, max_senses, d_model=48, nhead=4,
                 num_layers=2, max_len=80, dropout=0.1):
        super().__init__()
        self.max_len = max_len
        self.max_senses = max_senses
        self.token_emb = nn.Embedding(vocab_size, d_model, padding_idx=0)
        self.pos_emb = nn.Embedding(max_len, d_model)
        self.abbr_emb = nn.Embedding(num_abbrs, d_model)
        encoder_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead, dim_feedforward=d_model * 2,
            dropout=dropout, batch_first=True, activation="gelu",
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.classifier = nn.Sequential(
            nn.Linear(d_model * 2, d_model), nn.GELU(), nn.Dropout(dropout),
            nn.Linear(d_model, max_senses),
        )

    def forward(self, token_ids, abbr_ids):
        B, L = token_ids.shape
        pad_mask = token_ids == 0
        pos_ids = torch.arange(L, device=token_ids.device).unsqueeze(0).expand(B, L)
        x = self.token_emb(token_ids) + self.pos_emb(pos_ids)
        enc = self.encoder(x, src_key_padding_mask=pad_mask)
        # mean pool over non-pad tokens
        mask = (~pad_mask).unsqueeze(-1).float()
        pooled = (enc * mask).sum(1) / mask.sum(1).clamp(min=1)
        abbr_vec = self.abbr_emb(abbr_ids)
        combined = torch.cat([pooled, abbr_vec], dim=-1)
        logits = self.classifier(combined)
        return logits


class SmallTransformerWSD:
    """Wraps SmallTransformerModel with a sklearn-like fit/predict API."""

    def __init__(self, context_field="context_3", max_len=80, epochs=15, lr=2e-3, batch_size=32):
        self.context_field = context_field
        self.max_len = max_len
        self.epochs = epochs
        self.lr = lr
        self.batch_size = batch_size
        self.vocab = None
        self.abbr2id = {}
        self.max_senses = 1
        self.model = None
        self.device = "cpu"

    def _prep(self, records, fit_vocab=False):
        if fit_vocab:
            self.vocab = Vocab().build([r[self.context_field] for r in records])
            abbrs = sorted(set(r["abbreviation"] for r in records))
            self.abbr2id = {a: i for i, a in enumerate(abbrs)}
            self.max_senses = max(r["num_candidates"] for r in records)
        token_ids = torch.tensor(
            [self.vocab.encode(r[self.context_field], self.max_len) for r in records], dtype=torch.long)
        abbr_ids = torch.tensor(
            [self.abbr2id.get(r["abbreviation"], 0) for r in records], dtype=torch.long)
        labels = torch.tensor([r["label"] for r in records], dtype=torch.long)
        num_candidates = torch.tensor([r["num_candidates"] for r in records], dtype=torch.long)
        return token_ids, abbr_ids, labels, num_candidates

    def fit(self, train_records, val_records=None, verbose=True):
        tok_ids, abbr_ids, labels, num_cand = self._prep(train_records, fit_vocab=True)
        self.model = SmallTransformerModel(
            vocab_size=len(self.vocab), num_abbrs=len(self.abbr2id),
            max_senses=self.max_senses, max_len=self.max_len,
        ).to(self.device)
        opt = torch.optim.AdamW(self.model.parameters(), lr=self.lr, weight_decay=1e-4)
        n = tok_ids.shape[0]
        history = []
        for epoch in range(self.epochs):
            self.model.train()
            perm = torch.randperm(n)
            total_loss, correct = 0.0, 0
            for i in range(0, n, self.batch_size):
                idx = perm[i:i + self.batch_size]
                bt, ba, bl, bnc = tok_ids[idx], abbr_ids[idx], labels[idx], num_cand[idx]
                logits = self.model(bt, ba)
                # mask invalid candidate slots per-sample
                mask = torch.arange(self.max_senses).unsqueeze(0) >= bnc.unsqueeze(1)
                logits = logits.masked_fill(mask, float("-inf"))
                loss = F.cross_entropy(logits, bl)
                opt.zero_grad()
                loss.backward()
                opt.step()
                total_loss += loss.item() * len(idx)
                correct += (logits.argmax(-1) == bl).sum().item()
            train_acc = correct / n
            train_loss = total_loss / n
            val_acc = None
            if val_records:
                val_preds, val_confs, _ = self.predict(val_records)
                val_labels = [r["label"] for r in val_records]
                val_acc = float(np.mean([p == l for p, l in zip(val_preds, val_labels)]))
            history.append({"epoch": epoch, "train_loss": train_loss, "train_acc": train_acc, "val_acc": val_acc})
            if verbose:
                msg = f"epoch {epoch+1}/{self.epochs}  loss={train_loss:.4f}  train_acc={train_acc:.3f}"
                if val_acc is not None:
                    msg += f"  val_acc={val_acc:.3f}"
                print(msg)
        self.history = history
        return self

    @torch.no_grad()
    def predict(self, records):
        self.model.eval()
        tok_ids, abbr_ids, labels, num_cand = self._prep(records, fit_vocab=False)
        preds, confs, prob_dists = [], [], []
        for i in range(0, tok_ids.shape[0], 128):
            bt, ba, bnc = tok_ids[i:i+128], abbr_ids[i:i+128], num_cand[i:i+128]
            logits = self.model(bt, ba)
            mask = torch.arange(self.max_senses).unsqueeze(0) >= bnc.unsqueeze(1)
            logits = logits.masked_fill(mask, float("-inf"))
            probs = F.softmax(logits, dim=-1).numpy()
            for row, nc in zip(probs, bnc.numpy()):
                row = row[:nc]
                preds.append(int(np.argmax(row)))
                confs.append(float(np.max(row)))
                prob_dists.append(row.tolist())
        return preds, confs, prob_dists
