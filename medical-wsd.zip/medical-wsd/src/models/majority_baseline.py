"""Model 1 - Majority Sense baseline: predicts the most frequent sense
observed in TRAINING data for each abbreviation."""
import json
from collections import Counter, defaultdict


class MajorityBaseline:
    def __init__(self):
        self.majority_label = {}  # abbr -> label index
        self.majority_freq = {}   # abbr -> fraction of train examples with that label

    def fit(self, records):
        by_abbr = defaultdict(list)
        for r in records:
            by_abbr[r["abbreviation"]].append(r["label"])
        for abbr, labels in by_abbr.items():
            counts = Counter(labels)
            top_label, top_count = counts.most_common(1)[0]
            self.majority_label[abbr] = top_label
            self.majority_freq[abbr] = top_count / len(labels)
        return self

    def predict_one(self, record):
        abbr = record["abbreviation"]
        pred = self.majority_label.get(abbr, 0)
        conf = self.majority_freq.get(abbr, 1.0 / max(record.get("num_candidates", 1), 1))
        n = record.get("num_candidates", 1)
        # Build a simple confidence distribution: majority class gets `conf`,
        # remainder split uniformly among other candidates.
        probs = [(1 - conf) / max(n - 1, 1)] * n
        if pred < n:
            probs[pred] = conf
        return pred, probs

    def predict(self, records):
        preds, confs, prob_dists = [], [], []
        for r in records:
            pred, probs = self.predict_one(r)
            preds.append(pred)
            confs.append(max(probs))
            prob_dists.append(probs)
        return preds, confs, prob_dists
