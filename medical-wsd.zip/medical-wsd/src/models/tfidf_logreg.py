"""Model 2 - Classical NLP: TF-IDF (word + char n-grams) + Logistic
Regression. One classifier is trained per abbreviation, since each
abbreviation has its own candidate-sense label space (spec section 8)."""
from collections import defaultdict
import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import FeatureUnion
from sklearn.exceptions import ConvergenceWarning
import warnings

warnings.filterwarnings("ignore", category=ConvergenceWarning)


class TfidfLogRegWSD:
    def __init__(self, context_field="context_2"):
        self.context_field = context_field
        self.vectorizers = {}
        self.classifiers = {}
        self.n_classes = {}

    def _make_vectorizer(self):
        return FeatureUnion([
            ("word", TfidfVectorizer(ngram_range=(1, 2), min_df=1, sublinear_tf=True)),
            ("char", TfidfVectorizer(analyzer="char_wb", ngram_range=(3, 5), min_df=1)),
        ])

    def fit(self, records):
        by_abbr = defaultdict(list)
        for r in records:
            by_abbr[r["abbreviation"]].append(r)
        for abbr, recs in by_abbr.items():
            texts = [r[self.context_field] for r in recs]
            labels = [r["label"] for r in recs]
            n_classes = recs[0]["num_candidates"]
            self.n_classes[abbr] = n_classes
            if len(set(labels)) < 2:
                # Only one sense observed in training for this abbreviation;
                # store as a trivial (no-vectorizer) predictor.
                self.vectorizers[abbr] = None
                self.classifiers[abbr] = labels[0]
                continue
            vec = self._make_vectorizer()
            X = vec.fit_transform(texts)
            clf = LogisticRegression(max_iter=1000, C=2.0)
            clf.fit(X, labels)
            self.vectorizers[abbr] = vec
            self.classifiers[abbr] = clf
        return self

    def predict_one(self, record):
        abbr = record["abbreviation"]
        n = record.get("num_candidates", self.n_classes.get(abbr, 1))
        vec = self.vectorizers.get(abbr)
        clf = self.classifiers.get(abbr)
        if vec is None:
            # trivial predictor
            probs = [0.0] * n
            probs[clf] = 1.0
            return clf, probs
        X = vec.transform([record[self.context_field]])
        proba = clf.predict_proba(X)[0]
        # map classifier's internal classes_ (may be subset of 0..n-1) to full prob vector
        probs = [0.0] * n
        for cls, p in zip(clf.classes_, proba):
            probs[cls] = p
        pred = int(np.argmax(probs))
        return pred, probs

    def predict(self, records):
        preds, confs, prob_dists = [], [], []
        for r in records:
            pred, probs = self.predict_one(r)
            preds.append(pred)
            confs.append(max(probs))
            prob_dists.append(probs)
        return preds, confs, prob_dists
