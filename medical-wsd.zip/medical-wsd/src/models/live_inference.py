"""
Live WSD inference: detects known abbreviations in free-text input,
extracts context, and runs the trained TF-IDF+LogReg model (fast, no
retraining needed) to predict sense + confidence + candidate senses +
context signal words.

Uses TF-IDF+LogReg (not the transformer) for the live demo since it's
near-instant to load/run and both models perform equivalently on the
in-domain test set (see model_comparison.json).
"""
import re
import pickle
from src.data.abbreviation_dictionary import ABBREVIATION_DICT


def detect_abbreviations(text):
    found = []
    for abbr in ABBREVIATION_DICT:
        if re.search(rf"\b{re.escape(abbr)}\b", text):
            found.append(abbr)
    return found


def build_context_record(text, abbr):
    senses = ABBREVIATION_DICT[abbr]["senses"]
    candidate_senses = [s[0] for s in senses]
    return {
        "context_2": text,
        "context_3": text,
        "abbreviation": abbr,
        "num_candidates": len(senses),
        "candidate_senses": candidate_senses,
    }


def find_context_signals(text, abbr):
    """Returns cue words from the dictionary that literally appear in the
    input text, for any candidate sense of this abbreviation - i.e. the
    lexical evidence actually present, not a fabricated explanation."""
    signals = {}
    for sense_label, specialty, cues in ABBREVIATION_DICT[abbr]["senses"]:
        hits = [c for c in cues if c.lower() in text.lower()]
        if hits:
            signals[sense_label] = hits
    return signals


def run_live_wsd(text, model, uncertainty_threshold=0.5):
    abbrs = detect_abbreviations(text)
    results = []
    for abbr in abbrs:
        record = build_context_record(text, abbr)
        pred_idx, probs = model.predict_one(record)
        senses = record["candidate_senses"]
        confidence = probs[pred_idx] if pred_idx < len(probs) else 0.0
        signals = find_context_signals(text, abbr)
        is_uncertain = confidence < uncertainty_threshold
        results.append({
            "abbreviation": abbr,
            "predicted_sense": "UNCERTAIN — HUMAN REVIEW" if is_uncertain else senses[pred_idx],
            "raw_predicted_sense": senses[pred_idx],
            "confidence": float(confidence),
            "is_uncertain": is_uncertain,
            "candidate_senses": list(zip(senses, [float(p) for p in probs])),
            "context_signals": signals,
        })
    return results
