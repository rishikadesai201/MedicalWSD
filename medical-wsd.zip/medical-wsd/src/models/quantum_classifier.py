"""
Model 4 - Quantum Variational Classifier (QVC) for medical abbreviation WSD.

HONESTY NOTE (read before running on any dataset):
  - This runs on a CLASSICAL SIMULATOR of a quantum circuit (PennyLane's
    "default.qubit" device), not real quantum hardware. There is no
    quantum-hardware access in this environment, and, as of this writing,
    no published evidence that quantum hardware offers an advantage for
    a task this size. Simulating a quantum circuit classically becomes
    exponentially expensive with qubit count, which is why this model is
    restricted to a small number of qubits (n_qubits, default 6-8) and a
    dimensionality-reduced feature vector rather than full TF-IDF/BERT-scale
    features.
  - This is included as an EXPLORATORY comparison point against the
    classical models (Majority, TF-IDF+LogReg, Transformer), not as a
    claim that it outperforms them. Expect it to perform worse than the
    classical baselines given its far smaller effective capacity - that
    is an honest, reportable finding in itself, not a failure to hide.
  - This module is data-source agnostic: it consumes the SAME standardized
    record schema as the other three models (context field + label +
    num_candidates) and does not care whether those records came from
    MeDAL, MTSamples, CASI, or any other real corpus. It must NOT be run
    against the project's synthetic generator and reported as a result -
    only against real text data, consistent with the rest of the project.

Architecture:
  1. Classical preprocessing: TF-IDF (word n-grams) over the chosen
     context field, fit per-abbreviation exactly like the classical model.
  2. Classical dimensionality reduction: TruncatedSVD down to n_qubits
     components (a quantum circuit with n_qubits qubits can only
     natively accept n_qubits real-valued rotation angles per layer under
     angle encoding, so this reduction is a hard resource constraint, not
     a stylistic choice).
  3. Quantum feature encoding: each reduced feature is encoded as a
     single-qubit RY rotation angle (angle embedding).
  4. Variational ansatz: L layers of PennyLane's StronglyEntanglingLayers,
     trainable parameters optimized via backpropagation through the
     simulator (exact gradients on a simulator; on real hardware this
     would use the parameter-shift rule instead).
  5. Readout: a fixed number of qubits are measured in the Pauli-Z basis;
     their expectation values are linearly mapped to per-class logits and
     passed through softmax, restricted to the abbreviation's valid
     candidate senses exactly as in the classical models.
"""
from collections import defaultdict

import numpy as np
import pennylane as qml
from pennylane import numpy as pnp
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD


class QuantumVariationalWSD:
    def __init__(self, context_field="context_2", n_qubits=6, n_layers=3,
                 epochs=60, lr=0.1, seed=42, max_tfidf_features=200):
        self.context_field = context_field
        self.n_qubits = n_qubits
        self.n_layers = n_layers
        self.epochs = epochs
        self.lr = lr
        self.seed = seed
        self.max_tfidf_features = max_tfidf_features

        self.vectorizers = {}   # abbr -> TfidfVectorizer
        self.reducers = {}      # abbr -> TruncatedSVD
        self.weights = {}       # abbr -> trained circuit weights
        self.readout_maps = {}  # abbr -> linear readout (W, b) mapping expvals -> logits
        self.n_classes = {}
        self.trivial = {}       # abbr -> label, if only one class was observed

        self.device = qml.device("default.qubit", wires=self.n_qubits)
        self._build_circuit()

    def _build_circuit(self):
        n_qubits = self.n_qubits

        @qml.qnode(self.device, interface="autograd")
        def circuit(features, weights):
            # features: (batch, n_qubits) -- PennyLane broadcasts this into a
            # batched circuit execution, which is far faster than a Python
            # loop over samples calling the simulator once each.
            qml.AngleEmbedding(features, wires=range(n_qubits), rotation="Y")
            qml.StronglyEntanglingLayers(weights, wires=range(n_qubits))
            return [qml.expval(qml.PauliZ(w)) for w in range(n_qubits)]

        self.circuit = circuit

    def _softmax_batch(self, logits):
        # logits: (batch, n_classes)
        logits = logits - pnp.max(logits, axis=1, keepdims=True)
        e = pnp.exp(logits)
        return e / pnp.sum(e, axis=1, keepdims=True)

    def _forward_batch(self, X, weights, readout_W, readout_b, n_classes):
        expvals = self.circuit(X, weights)              # list of n_qubits arrays, each (batch,)
        expvals = pnp.stack(expvals, axis=1)             # (batch, n_qubits)
        logits = pnp.dot(expvals, readout_W[:n_classes].T) + readout_b[:n_classes]  # (batch, n_classes)
        return self._softmax_batch(logits)

    def fit(self, records, verbose=True):
        rng = np.random.default_rng(self.seed)
        by_abbr = defaultdict(list)
        for r in records:
            by_abbr[r["abbreviation"]].append(r)

        for abbr, recs in by_abbr.items():
            texts = [r[self.context_field] for r in recs]
            labels = [r["label"] for r in recs]
            n_classes = recs[0]["num_candidates"]
            self.n_classes[abbr] = n_classes

            if len(set(labels)) < 2:
                self.trivial[abbr] = labels[0]
                continue

            vec = TfidfVectorizer(max_features=self.max_tfidf_features, ngram_range=(1, 1))
            X_tfidf = vec.fit_transform(texts).toarray()
            n_components = min(self.n_qubits, X_tfidf.shape[1], max(X_tfidf.shape[0] - 1, 1))
            reducer = TruncatedSVD(n_components=n_components, random_state=self.seed)
            X_reduced = reducer.fit_transform(X_tfidf)
            # pad up to n_qubits if the reducer gave fewer components
            if X_reduced.shape[1] < self.n_qubits:
                pad = np.zeros((X_reduced.shape[0], self.n_qubits - X_reduced.shape[1]))
                X_reduced = np.hstack([X_reduced, pad])
            # scale to a valid rotation-angle range
            norm = np.abs(X_reduced).max() or 1.0
            X_reduced = (X_reduced / norm) * np.pi

            weight_shape = qml.StronglyEntanglingLayers.shape(n_layers=self.n_layers, n_wires=self.n_qubits)
            weights = pnp.array(rng.normal(0, 0.1, size=weight_shape), requires_grad=True)
            readout_W = pnp.array(rng.normal(0, 0.5, size=(n_classes, self.n_qubits)), requires_grad=True)
            readout_b = pnp.array(np.zeros(n_classes), requires_grad=True)

            opt = qml.AdamOptimizer(stepsize=self.lr)
            y = np.array(labels)
            X_all = pnp.array(X_reduced)

            def cost(weights, readout_W, readout_b):
                probs = self._forward_batch(X_all, weights, readout_W, readout_b, n_classes)
                true_probs = probs[pnp.arange(len(y)), y]
                return -pnp.mean(pnp.log(true_probs + 1e-9))

            for epoch in range(self.epochs):
                weights, readout_W, readout_b = opt.step(
                    lambda w, rw, rb: cost(w, rw, rb), weights, readout_W, readout_b
                )
                if verbose and (epoch + 1) % max(self.epochs // 5, 1) == 0:
                    c = cost(weights, readout_W, readout_b)
                    print(f"  [quantum:{abbr}] epoch {epoch+1}/{self.epochs} loss={float(c):.4f}")

            self.vectorizers[abbr] = vec
            self.reducers[abbr] = (reducer, norm)
            self.weights[abbr] = weights
            self.readout_maps[abbr] = (readout_W, readout_b)

    def predict_one(self, record):
        abbr = record["abbreviation"]
        n_classes = record.get("num_candidates", self.n_classes.get(abbr, 1))
        if abbr in self.trivial:
            probs = [0.0] * n_classes
            probs[self.trivial[abbr]] = 1.0
            return self.trivial[abbr], probs

        vec = self.vectorizers[abbr]
        reducer, norm = self.reducers[abbr]
        weights = self.weights[abbr]
        readout_W, readout_b = self.readout_maps[abbr]

        X_tfidf = vec.transform([record[self.context_field]]).toarray()
        X_reduced = reducer.transform(X_tfidf)
        if X_reduced.shape[1] < self.n_qubits:
            pad = np.zeros((1, self.n_qubits - X_reduced.shape[1]))
            X_reduced = np.hstack([X_reduced, pad])
        X_reduced = (X_reduced / norm) * np.pi

        probs = self._forward_batch(pnp.array(X_reduced), weights, readout_W, readout_b, n_classes)
        probs = np.array(probs[0])
        pred = int(np.argmax(probs))
        return pred, probs.tolist()

    def predict(self, records):
        preds, confs, prob_dists = [], [], []
        for r in records:
            pred, probs = self.predict_one(r)
            preds.append(pred)
            confs.append(max(probs))
            prob_dists.append(probs)
        return preds, confs, prob_dists
