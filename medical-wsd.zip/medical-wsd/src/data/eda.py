"""Exploratory data analysis for the synthetic WSD dataset."""
import json
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns
from pathlib import Path

sns.set_theme(style="whitegrid")


def load_df(path):
    records = [json.loads(l) for l in open(path)]
    return pd.DataFrame(records)


def compute_stats(df):
    abbr_sense_counts = df.groupby("abbreviation")["sense"].nunique()
    stats = {
        "total_samples": int(len(df)),
        "unique_abbreviations": int(df["abbreviation"].nunique()),
        "unique_senses": int(df["sense"].nunique()),
        "num_ambiguous_abbreviations": int((abbr_sense_counts > 1).sum()),
        "num_unambiguous_abbreviations": int((abbr_sense_counts == 1).sum()),
        "specialties": sorted(df["specialty"].unique().tolist()),
        "num_specialties": int(df["specialty"].nunique()),
        "avg_context2_length_words": float(df["context_2_length"].mean()),
        "avg_context4_length_words": float(df["context_4_length"].mean()),
        "most_frequent_abbreviations": df["abbreviation"].value_counts().head(5).to_dict(),
        "most_ambiguous_abbreviations": abbr_sense_counts.sort_values(ascending=False).head(5).to_dict(),
        "rarest_abbreviations": df["abbreviation"].value_counts().tail(5).to_dict(),
        "split_sizes": df["split"].value_counts().to_dict(),
        "vocabulary_size": len(set(" ".join(df["context_4"]).lower().split())),
    }
    return stats


def make_plots(df, outdir):
    Path(outdir).mkdir(parents=True, exist_ok=True)

    fig, ax = plt.subplots(figsize=(9, 5))
    df["abbreviation"].value_counts().plot(kind="bar", ax=ax, color="#3b6fa0")
    ax.set_title("Abbreviation Frequency (Synthetic Dataset)")
    ax.set_ylabel("Count")
    plt.tight_layout()
    fig.savefig(f"{outdir}/abbreviation_frequency.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(9, 5))
    df["sense"].value_counts().head(20).plot(kind="barh", ax=ax, color="#5b9279")
    ax.set_title("Top 20 Sense Distribution")
    plt.tight_layout()
    fig.savefig(f"{outdir}/sense_distribution.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(7, 5))
    class_counts = df.groupby("abbreviation")["sense"].nunique().value_counts().sort_index()
    class_counts.plot(kind="bar", ax=ax, color="#a05b5b")
    ax.set_title("Class Imbalance: # Candidate Senses per Abbreviation")
    ax.set_xlabel("Number of candidate senses")
    ax.set_ylabel("Number of abbreviations")
    plt.tight_layout()
    fig.savefig(f"{outdir}/class_imbalance.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    df["specialty"].value_counts().plot(kind="bar", ax=ax, color="#8a6fa0")
    ax.set_title("Specialty Distribution (procedurally assigned, synthetic)")
    plt.tight_layout()
    fig.savefig(f"{outdir}/domain_distribution.png", dpi=150)
    plt.close(fig)

    fig, ax = plt.subplots(figsize=(8, 5))
    ax.hist(df["context_4_length"], bins=20, color="#3b6fa0", alpha=0.8, label="Context 4 (±2 sent.)")
    ax.hist(df["context_2_length"], bins=20, color="#a05b5b", alpha=0.6, label="Context 2 (sentence)")
    ax.set_title("Context Length Distribution (words)")
    ax.set_xlabel("Words")
    ax.legend()
    plt.tight_layout()
    fig.savefig(f"{outdir}/context_length.png", dpi=150)
    plt.close(fig)


def run(input_path="data/processed/synthetic_wsd_preprocessed.jsonl",
        out_stats="results/metrics/eda_stats.json",
        out_plots="paper/figures"):
    df = load_df(input_path)
    stats = compute_stats(df)
    Path(out_stats).parent.mkdir(parents=True, exist_ok=True)
    with open(out_stats, "w") as f:
        json.dump(stats, f, indent=2)
    make_plots(df, out_plots)
    return stats


if __name__ == "__main__":
    stats = run()
    print(json.dumps(stats, indent=2))
