"""
Abbreviation-sense dictionary for the REAL MTSamples dataset.

Unlike src/data/abbreviation_dictionary.py (used for the synthetic
generator), every sense listed here was empirically verified against the
uploaded mtsamples.csv. Initial labeling used document-level distant
supervision (full-form mention anywhere in the same document), but manual
spot-checking revealed this produces real, systematic mislabeling: many
MTSamples documents mention a sense's full form in an unrelated section
while the actual abbreviation occurrence locally indicates a different
sense entirely (e.g. a document mentioning "physician assistant" in a
signature line while a "PA" elsewhere in the same note clearly means a
chest x-ray view; "AV groove/trunk/nodal/sulcus" always meaning
atrioventricular anatomy even in documents that separately mention
"aortic valve"; "AP diameter/window/pelvis/view" always meaning
anteroposterior even in documents that separately mention "abdominal
pain"). To correct this, labels here are assigned using LOCAL
sentence-level lexical evidence as the primary signal (see
LOCAL_SENSE_PATTERNS in real_mtsamples_loader.py), falling back to
whole-document full-form confirmation only when no local evidence exists
for any candidate sense. Occurrences with conflicting or absent evidence
are excluded rather than guessed.
"""

# abbr -> {"senses": [(sense_label, specialty_hint, [full_form_variants])]}
# specialty_hint is NOT used as ground truth (the real medical_specialty
# column from MTSamples is used for that) - it's only a fallback label.
REAL_ABBREVIATION_DICT = {
    "LAD": {
        "senses": [
            ("Left Anterior Descending", "Cardiovascular / Pulmonary", ["left anterior descending"]),
            ("Left Axis Deviation", "Cardiovascular / Pulmonary", ["left axis deviation"]),
        ],
    },
    "PE": {
        "senses": [
            ("Pulmonary Embolism", "Cardiovascular / Pulmonary", ["pulmonary embolism"]),
            ("Physical Examination", "General Medicine", ["physical examination"]),
            ("Pleural Effusion", "Cardiovascular / Pulmonary", ["pleural effusion"]),
        ],
    },
    "MS": {
        "senses": [
            ("Multiple Sclerosis", "Neurology", ["multiple sclerosis"]),
            ("Mental Status", "General Medicine", ["mental status"]),
        ],
    },
    "AV": {
        "senses": [
            ("Atrioventricular", "Cardiovascular / Pulmonary", ["atrioventricular"]),
            ("Arteriovenous", "Cardiovascular / Pulmonary", ["arteriovenous"]),
        ],
    },
    "AP": {
        "senses": [
            ("Abdominal Pain", "Gastroenterology", ["abdominal pain"]),
            ("Anteroposterior", "Radiology", ["anteroposterior"]),
        ],
    },
    "CA": {
        "senses": [
            ("Cancer", "Hematology - Oncology", ["cancer"]),
            ("Calcium", "General Medicine", ["calcium"]),
        ],
    },
    "PA": {
        "senses": [
            ("Physician Assistant", "General Medicine", ["physician assistant"]),
            ("Pulmonary Artery", "Cardiovascular / Pulmonary", ["pulmonary artery"]),
        ],
    },
    "PDA": {
        "senses": [
            ("Patent Ductus Arteriosus", "Cardiovascular / Pulmonary", ["patent ductus arteriosus"]),
            ("Posterior Descending Artery", "Cardiovascular / Pulmonary", ["posterior descending artery"]),
        ],
    },
}

