"""
Curated medical abbreviation -> candidate sense dictionary.

This dictionary encodes real, well-documented medical abbreviation senses
(the kind found in clinical abbreviation references). It is used as the
SEED for a synthetic sentence generator (see synthetic_generator.py) -
the sentences themselves are template-generated, not real patient text.

Every abbreviation entry contains:
    - senses: list of (sense_label, specialty, cue_words)
        cue_words are terms that plausibly co-occur with that sense and
        are used by the generator to build context-bearing synthetic
        sentences (and later used as ground truth for "context signal"
        highlighting in the live demo).
"""

ABBREVIATION_DICT = {
    "MS": {
        "senses": [
            ("Multiple Sclerosis", "Neurology",
             ["demyelination", "optic neuritis", "relapsing-remitting", "MRI lesions", "numbness", "gait instability"]),
            ("Mitral Stenosis", "Cardiology",
             ["mitral valve", "diastolic murmur", "atrial fibrillation", "dyspnea on exertion", "echocardiogram"]),
            ("Mental Status", "General",
             ["alert and oriented", "confusion", "responsiveness", "GCS", "cognitive exam"]),
        ],
    },
    "CHF": {
        "senses": [
            ("Congestive Heart Failure", "Cardiology",
             ["reduced ejection fraction", "dyspnea", "pulmonary edema", "orthopnea", "jugular venous distension", "BNP elevated"]),
        ],
    },
    "CVA": {
        "senses": [
            ("Cerebrovascular Accident", "Neurology",
             ["stroke", "hemiparesis", "slurred speech", "facial droop", "CT head", "thrombolysis"]),
            ("Costovertebral Angle", "General",
             ["tenderness", "flank pain", "percussion", "pyelonephritis"]),
        ],
    },
    "PE": {
        "senses": [
            ("Pulmonary Embolism", "Pulmonology",
             ["shortness of breath", "chest pain", "D-dimer", "CT angiogram", "hypoxia", "tachycardia"]),
            ("Physical Examination", "General",
             ["auscultation", "vital signs", "inspection", "palpation", "clinical exam"]),
            ("Pleural Effusion", "Pulmonology",
             ["decreased breath sounds", "chest X-ray", "thoracentesis", "dullness to percussion"]),
        ],
    },
    "DM": {
        "senses": [
            ("Diabetes Mellitus", "Endocrinology",
             ["hyperglycemia", "insulin", "A1C", "polyuria", "polydipsia", "blood glucose"]),
            ("Diastolic Murmur", "Cardiology",
             ["auscultation", "mitral valve", "aortic regurgitation", "echocardiogram"]),
        ],
    },
    "RA": {
        "senses": [
            ("Rheumatoid Arthritis", "Rheumatology",
             ["joint swelling", "morning stiffness", "anti-CCP", "synovitis", "symmetric polyarthritis"]),
            ("Right Atrium", "Cardiology",
             ["echocardiogram", "atrial pressure", "catheterization", "right heart"]),
        ],
    },
    "MI": {
        "senses": [
            ("Myocardial Infarction", "Cardiology",
             ["chest pain", "troponin", "ST elevation", "ECG changes", "coronary occlusion"]),
            ("Mitral Insufficiency", "Cardiology",
             ["regurgitant murmur", "echocardiogram", "mitral valve prolapse"]),
        ],
    },
    "BS": {
        "senses": [
            ("Blood Sugar", "Endocrinology",
             ["glucose level", "fasting", "insulin", "hypoglycemia"]),
            ("Bowel Sounds", "General",
             ["auscultation", "abdomen", "peristalsis", "hypoactive"]),
            ("Breath Sounds", "Pulmonology",
             ["auscultation", "wheezing", "crackles", "diminished"]),
        ],
    },
    "OA": {
        "senses": [
            ("Osteoarthritis", "Rheumatology",
             ["joint space narrowing", "crepitus", "weight-bearing pain", "cartilage degeneration"]),
            ("Osteoarthropathy", "General",
             ["periosteal reaction", "clubbing", "long bones"]),
        ],
    },
    "PT": {
        "senses": [
            ("Physical Therapy", "General",
             ["rehabilitation", "range of motion", "mobility exercises", "strength training"]),
            ("Prothrombin Time", "General",
             ["coagulation panel", "INR", "anticoagulation", "warfarin"]),
        ],
    },
    "AF": {
        "senses": [
            ("Atrial Fibrillation", "Cardiology",
             ["irregularly irregular", "palpitations", "ECG", "anticoagulation", "rate control"]),
            ("Amniotic Fluid", "General",
             ["ultrasound", "pregnancy", "gestational age"]),
        ],
    },
    "BP": {
        "senses": [
            ("Blood Pressure", "General",
             ["hypertension", "systolic", "diastolic", "sphygmomanometer"]),
            ("Bipolar Disorder", "Psychiatry",
             ["mood episodes", "mania", "depressive episode", "mood stabilizer"]),
        ],
    },
    "IBS": {
        "senses": [
            ("Irritable Bowel Syndrome", "Gastroenterology",
             ["abdominal cramping", "bowel habit changes", "bloating", "Rome criteria"]),
        ],
    },
    "GERD": {
        "senses": [
            ("Gastroesophageal Reflux Disease", "Gastroenterology",
             ["heartburn", "regurgitation", "acid reflux", "PPI therapy", "esophagitis"]),
        ],
    },
    "COPD": {
        "senses": [
            ("Chronic Obstructive Pulmonary Disease", "Pulmonology",
             ["dyspnea", "chronic cough", "smoking history", "spirometry", "FEV1"]),
        ],
    },
    "UTI": {
        "senses": [
            ("Urinary Tract Infection", "General",
             ["dysuria", "urinary frequency", "urinalysis", "bacteriuria"]),
        ],
    },
    "HTN": {
        "senses": [
            ("Hypertension", "Cardiology",
             ["elevated blood pressure", "antihypertensive", "systolic pressure"]),
        ],
    },
    "ARF": {
        "senses": [
            ("Acute Renal Failure", "Nephrology",
             ["elevated creatinine", "oliguria", "GFR decline", "electrolyte imbalance"]),
            ("Acute Rheumatic Fever", "Rheumatology",
             ["Jones criteria", "post-streptococcal", "carditis", "polyarthritis"]),
        ],
    },
    "ID": {
        "senses": [
            ("Infectious Disease", "Infectious Disease",
             ["fever", "culture positive", "antibiotic therapy", "pathogen"]),
            ("Identification", "General",
             ["patient identification", "record verification", "chart"]),
        ],
    },
    "FH": {
        "senses": [
            ("Family History", "General",
             ["hereditary", "genetic predisposition", "relatives", "pedigree"]),
        ],
    },
}


def get_all_abbreviations():
    return list(ABBREVIATION_DICT.keys())


def get_senses(abbr):
    return ABBREVIATION_DICT[abbr]["senses"]


def get_specialties():
    specialties = set()
    for abbr, info in ABBREVIATION_DICT.items():
        for sense_label, specialty, _ in info["senses"]:
            specialties.add(specialty)
    return sorted(specialties)
