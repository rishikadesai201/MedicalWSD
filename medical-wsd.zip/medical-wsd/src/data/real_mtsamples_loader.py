"""
Builds a REAL medical abbreviation WSD dataset from the uploaded MTSamples
CSV. Labels are assigned primarily from LOCAL (same-sentence) lexical
evidence (see LOCAL_SENSE_PATTERNS), falling back to whole-document
full-form co-occurrence (distant supervision, the same core principle
MeDAL itself uses) only when no local evidence exists. Occurrences with
no evidence, or with conflicting local evidence for more than one sense,
are excluded rather than guessed - see real_abbreviation_dictionary.py
for why local evidence is required as the primary signal.

Ground-truth specialty comes directly from MTSamples' own
`medical_specialty` column (real metadata, not inferred).

Output schema matches the rest of the project exactly (see
src/preprocessing/pipeline.py), so it drops straight into run_quantum.py
and all existing model code with zero changes.
"""
import json
import re
from pathlib import Path
from collections import defaultdict

import pandas as pd

from src.data.real_abbreviation_dictionary import REAL_ABBREVIATION_DICT
from src.preprocessing.pipeline import build_context_windows, clean_text

SENTENCE_SPLIT_RE = re.compile(r'(?<=[.!?])\s+')

# Local (same-sentence) lexical evidence per sense, grounded in standard
# clinical/radiology/cardiology terminology. This is the PRIMARY labeling
# signal (see module docstring for why document-level alone is unreliable).
# Each pattern is checked case-insensitively against the sentence
# containing the abbreviation occurrence.
LOCAL_SENSE_PATTERNS = {
    ("LAD", "Left Anterior Descending"): [
        r"left anterior descending", r"stenosis", r"bifurcat", r"circumflex",
        r"coronary", r"catheter", r"stent", r"diagonal", r"angioplasty",
        r"\bpci\b", r"occlu", r"calcifi", r"vessel", r"wraps around",
    ],
    ("LAD", "Left Axis Deviation"): [r"left axis deviation", r"\baxis deviation\b"],

    ("PE", "Pulmonary Embolism"): [r"pulmonary embolism", r"embol"],
    ("PE", "Pleural Effusion"): [r"pleural effusion", r"effusion"],
    ("PE", "Physical Examination"): [r"physical examination", r"vital signs", r"heent", r"auscultation"],

    ("MS", "Mental Status"): [
        r"mental status", r"a\s*&\s*o\b", r"alert and oriented", r"oriented to",
        r"disoriented", r"\bgcs\b",
    ],
    ("MS", "Multiple Sclerosis"): [
        r"multiple sclerosis", r"demyelinat", r"relapsing", r"optic neuritis",
    ],

    ("AV", "Atrioventricular"): [
        r"atrioventricular", r"\bnode\b", r"nodal", r"\bblock\b", r"conduction",
        r"\bgroove\b", r"\bsulcus\b", r"\btrunk\b", r"dissociation",
    ],
    ("AV", "Arteriovenous"): [r"arteriovenous", r"fistula", r"\bgraft\b", r"\bshunt\b", r"malformation"],

    ("AP", "Anteroposterior"): [
        r"anteroposterior", r"diameter", r"\bwindow\b", r"\bpelvis\b", r"\bview",
        r"\bfilm\b", r"x-?ray", r"radiograph", r"mortise",
    ],
    ("AP", "Abdominal Pain"): [r"abdominal pain", r"\babd\.?\s*pain\b"],

    ("CA", "Cancer"): [r"\bcancer\b", r"carcinoma", r"\btumor\b", r"malignant", r"metasta", r"chemo", r"oncolog"],
    ("CA", "Calcium"): [r"\bcalcium\b", r"calcif", r"hypercalcemia"],

    ("PA", "Pulmonary Artery"): [
        r"pulmonary artery", r"\bpressure\b", r"\bsaturation\b", r"\bwedge\b",
        r"right ventricle", r"cardiac output",
    ],
    ("PA", "Physician Assistant"): [r"physician assistant"],

    ("PDA", "Posterior Descending Artery"): [
        r"posterior descending", r"stenosis", r"\blesion\b", r"\bostium\b",
        r"dominant", r"occlusion",
    ],
    ("PDA", "Patent Ductus Arteriosus"): [
        r"patent ductus arteriosus", r"\bductus\b", r"glenn shunt", r"ligation",
    ],
}

# Known false-positive local contexts: these local phrases indicate a
# THIRD sense not in our candidate list at all (rather than either
# candidate), discovered via manual review. Excluded rather than
# mislabeled into one of the existing candidates.
LOCAL_EXCLUSION_PATTERNS = {
    "CA": [r"\bligament\b"],  # "CA ligament" = coracoacromial ligament, not Cancer/Calcium
}


def local_sense_match(abbr, sentence_lower, senses):
    """Returns the sense index with matching local evidence, or None if
    zero or multiple senses have local matches (ambiguous/no evidence)."""
    if any(re.search(p, sentence_lower) for p in LOCAL_EXCLUSION_PATTERNS.get(abbr, [])):
        return "EXCLUDE"
    matched = []
    for idx, (sense_label, _specialty, _variants) in enumerate(senses):
        patterns = LOCAL_SENSE_PATTERNS.get((abbr, sense_label), [])
        if any(re.search(p, sentence_lower) for p in patterns):
            matched.append(idx)
    if len(matched) == 1:
        return matched[0]
    return None


def split_sentences(text):
    text = re.sub(r'\s+', ' ', text).strip()
    parts = [s.strip() for s in SENTENCE_SPLIT_RE.split(text) if s.strip()]
    return parts


def find_sentence_index(sentences, abbr):
    pattern = re.compile(rf'\b{re.escape(abbr)}\b')
    for i, s in enumerate(sentences):
        if pattern.search(s):
            return i
    return None


def confirm_document_label(text_lower, senses):
    """Returns the sense index if exactly one sense's full form is present
    in this document, else None (no evidence or conflicting evidence)."""
    confirmed = []
    for idx, (sense_label, specialty_hint, variants) in enumerate(senses):
        if any(v in text_lower for v in variants):
            confirmed.append(idx)
    if len(confirmed) == 1:
        return confirmed[0]
    return None


def build_real_dataset(csv_path, splits=(0.7, 0.15, 0.15), seed=42):
    df = pd.read_csv(csv_path)
    df = df.dropna(subset=["transcription"])

    records = []
    rid = 0
    doc_label_counts = defaultdict(int)  # abbr -> count of labeled docs (for reporting)

    for _, row in df.iterrows():
        text = row["transcription"]
        text_lower = text.lower()
        specialty = row["medical_specialty"].strip() if isinstance(row["medical_specialty"], str) else "Unknown"
        abbr_pattern_cache = {}
        sentences_cache = None

        for abbr, info in REAL_ABBREVIATION_DICT.items():
            pattern = abbr_pattern_cache.setdefault(abbr, re.compile(rf'\b{re.escape(abbr)}\b'))
            if not pattern.search(text):
                continue

            doc_level_label = confirm_document_label(text_lower, info["senses"])

            if sentences_cache is None:
                sentences_cache = split_sentences(text)
            sentences = sentences_cache

            # process every occurrence in this document independently, since
            # local evidence (not just document-level) determines the label
            for m in pattern.finditer(text):
                # find which sentence this specific occurrence falls in
                sent_idx = None
                running_len = 0
                char_pos = m.start()
                cum = 0
                for i, s in enumerate(sentences):
                    cum += len(s) + 1
                    if cum >= char_pos:
                        sent_idx = i
                        break
                if sent_idx is None:
                    sent_idx = len(sentences) - 1

                sentence = sentences[sent_idx]
                sentence_lower = sentence.lower()

                local_label = local_sense_match(abbr, sentence_lower, info["senses"])
                if local_label == "EXCLUDE":
                    continue  # local evidence indicates an uncaptured 3rd sense - exclude, don't guess
                label_idx = local_label if local_label is not None else doc_level_label
                if label_idx is None:
                    continue  # no reliable evidence at all - exclude, don't guess

                doc_label_counts[abbr] += 1
                sense_label = info["senses"][label_idx][0]
                candidate_senses = [s[0] for s in info["senses"]]
                n_candidates = len(candidate_senses)

                prev_sentence = sentences[sent_idx - 1] if sent_idx - 1 >= 0 else ""
                prev_sentence2 = sentences[sent_idx - 2] if sent_idx - 2 >= 0 else ""
                next_sentence = sentences[sent_idx + 1] if sent_idx + 1 < len(sentences) else ""
                next_sentence2 = sentences[sent_idx + 2] if sent_idx + 2 < len(sentences) else ""

                full_text = " ".join(s for s in [prev_sentence2, prev_sentence, sentence, next_sentence, next_sentence2] if s)

                record = {
                    "id": rid,
                    "text": clean_text(full_text),
                    "sentence": sentence,
                    "prev_sentence": prev_sentence,
                    "prev_sentence2": prev_sentence2,
                    "next_sentence": next_sentence,
                    "next_sentence2": next_sentence2,
                    "abbreviation": abbr,
                    "target_span": f"[ABBR]{abbr}[/ABBR]",
                    "sense": sense_label,
                    "label": label_idx,
                    "num_candidates": n_candidates,
                    "candidate_senses": candidate_senses,
                    "domain": "clinical",
                    "specialty": specialty,
                    "source_doc_index": int(row.name),
                    "label_source": "local" if local_label is not None else "document_level",
                }
                records.append(record)
                rid += 1

    print("Real labeled documents per abbreviation (distant supervision, single-sense-confirmed only):")
    for abbr, cnt in sorted(doc_label_counts.items(), key=lambda x: -x[1]):
        print(f"  {abbr:6s} {cnt}")

    # Document-level split assignment to prevent leakage (all occurrences
    # from the same source document must land in the same split).
    import random
    rng = random.Random(seed)
    doc_indices = sorted(set(r["source_doc_index"] for r in records))
    rng.shuffle(doc_indices)
    n = len(doc_indices)
    n_train = int(n * splits[0])
    n_val = int(n * splits[1])
    split_map = {}
    for i, doc_idx in enumerate(doc_indices):
        if i < n_train:
            split_map[doc_idx] = "train"
        elif i < n_train + n_val:
            split_map[doc_idx] = "val"
        else:
            split_map[doc_idx] = "test"

    for r in records:
        r["split"] = split_map[r["source_doc_index"]]

    # add context windows using the SAME function the rest of the project uses
    final_records = []
    for r in records:
        rec = dict(r)
        rec.update(build_context_windows(r))
        rec["context_2_length"] = len(rec["context_2"].split())
        rec["context_4_length"] = len(rec["context_4"].split())
        final_records.append(rec)

    return final_records


def save_dataset(records, path):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w") as f:
        for r in records:
            f.write(json.dumps(r) + "\n")


if __name__ == "__main__":
    records = build_real_dataset("/mnt/user-data/uploads/mtsamples.csv")
    save_dataset(records, "data/processed/real_wsd_preprocessed.jsonl")

    print(f"\nTotal real labeled instances: {len(records)}")
    from collections import Counter
    print("By split:", Counter(r["split"] for r in records))
    print("By abbreviation:", Counter(r["abbreviation"] for r in records))
