"""
Abbreviation-centered preprocessing pipeline.

Builds the 4 context windows described in the spec:
    context_1: abbreviation only
    context_2: sentence containing the abbreviation
    context_3: +/-1 surrounding sentence
    context_4: +/-2 surrounding sentences

Also performs a leakage check (no identical `text` appearing in more than
one split) and light cleaning that preserves medical tokens, numbers, and
punctuation (per spec section 6).
"""
import json
import re
import pandas as pd


def load_jsonl(path):
    records = []
    with open(path) as f:
        for line in f:
            records.append(json.loads(line))
    return records


def clean_text(text):
    """Light cleaning: collapse whitespace only. Deliberately does NOT
    strip numbers, punctuation, or the [ABBR]...[/ABBR] markers, since
    those carry medically meaningful information (spec section 6)."""
    text = re.sub(r"\s+", " ", text).strip()
    return text


def build_context_windows(record):
    abbr = record["abbreviation"]
    windows = {
        "context_1": f"[ABBR]{abbr}[/ABBR]",
        "context_2": clean_text(record["sentence"]),
        "context_3": clean_text(f"{record['prev_sentence']} {record['sentence']} {record['next_sentence']}"),
        "context_4": clean_text(
            f"{record['prev_sentence2']} {record['prev_sentence']} {record['sentence']} "
            f"{record['next_sentence']} {record['next_sentence2']}"
        ),
    }
    return windows


def preprocess(records):
    out = []
    for r in records:
        rec = dict(r)
        rec["text"] = clean_text(rec["text"])
        rec.update(build_context_windows(r))
        rec["context_2_length"] = len(rec["context_2"].split())
        rec["context_4_length"] = len(rec["context_4"].split())
        out.append(rec)
    return out


def check_leakage(records):
    """Verify no exact-text duplication across splits (data leakage check)."""
    df = pd.DataFrame(records)
    text_to_splits = df.groupby("text")["split"].nunique()
    leaked = text_to_splits[text_to_splits > 1]
    return {
        "num_leaked_texts": int(len(leaked)),
        "leak_free": bool(len(leaked) == 0),
    }


def run(input_path, output_path):
    records = load_jsonl(input_path)
    processed = preprocess(records)
    leakage_report = check_leakage(processed)
    with open(output_path, "w") as f:
        for r in processed:
            f.write(json.dumps(r) + "\n")
    return processed, leakage_report


if __name__ == "__main__":
    processed, leakage = run(
        "data/processed/synthetic_wsd.jsonl",
        "data/processed/synthetic_wsd_preprocessed.jsonl",
    )
    print(f"Preprocessed {len(processed)} records.")
    print(f"Leakage check: {leakage}")
