"""
Experiment 4 - Data-Efficient Adaptation.

CAVEAT: The spec's intent is source(MeDAL)->target(real clinical) adaptation.
No real clinical corpus is reachable in this sandbox, so as a real (not
fabricated) stand-in, we designate ONE specialty's synthetic data as a
proxy "target domain" and the rest as "source domain", then fine-tune
progressively on 0/1/5/10/25/50/100% of the target specialty's training
data, evaluating on its held-out test data. This is a genuine experiment
run on synthetic data - it is explicitly NOT the real clinical adaptation
experiment, which remains pending real data access.
"""
import numpy as np
from src.models.tfidf_logreg import TfidfLogRegWSD
from src.evaluation.metrics import compute_core_metrics
from src.evaluation.calibration import expected_calibration_error_wrapper


PERCENTAGES = [0.0, 0.01, 0.05, 0.10, 0.25, 0.50, 1.00]


def run_data_efficiency(train_records, test_records, target_specialty="Neurology", seed=42):
    rng = np.random.RandomState(seed)
    source_train = [r for r in train_records if r["specialty"] != target_specialty]
    target_train_pool = [r for r in train_records if r["specialty"] == target_specialty]
    target_test = [r for r in test_records if r["specialty"] == target_specialty]

    if len(target_train_pool) < 5 or len(target_test) < 3:
        return {"error": f"insufficient data for target specialty {target_specialty}", "results": []}

    order = rng.permutation(len(target_train_pool))
    results = []
    for pct in PERCENTAGES:
        k = int(round(pct * len(target_train_pool)))
        subset_idx = order[:k]
        target_subset = [target_train_pool[i] for i in subset_idx]
        train_mix = source_train + target_subset
        # only abbreviations present are those relevant; classifier is per-abbreviation so
        # this naturally handles the "fine-tuning" via retraining with combined data
        model = TfidfLogRegWSD(context_field="context_2").fit(train_mix)
        preds, confs, prob_dists = model.predict(target_test)
        labels = [r["label"] for r in target_test]
        metrics = compute_core_metrics(labels, preds)
        correct = [p == l for p, l in zip(preds, labels)]
        ece, _ = expected_calibration_error_wrapper(confs, correct)
        results.append({
            "target_data_percentage": pct,
            "n_target_train_samples": k,
            "accuracy": metrics["accuracy"],
            "macro_f1": metrics["macro_f1"],
            "ece": ece,
        })
    return {
        "target_specialty": target_specialty,
        "n_target_train_pool": len(target_train_pool),
        "n_target_test": len(target_test),
        "results": results,
        "caveat": (
            "Run on synthetic data using a held-out specialty as a proxy target domain "
            "(source = all other specialties' synthetic data). This is NOT real clinical "
            "adaptation; that experiment is pending real clinical data access."
        ),
    }
