"""
Experiment 2 - Synthetic/PubMed-style -> Real Clinical (RQ1).

STATUS: PENDING. This experiment requires a legitimate, accessible,
de-identified real clinical text corpus (e.g. MIMIC-derived clinical
notes). This sandbox's network allowlist does not include PhysioNet,
Hugging Face Hub, or other dataset hosts, and MIMIC-derived data requires
credentialed access that cannot be completed here.

This module defines the exact interface the real experiment would use,
so that supplying a real clinical dataset (as a list of records in the
project's standardized schema: text, abbreviation, target_span, sense,
label, domain="clinical", specialty, split) would make this runnable
immediately, with zero other code changes.
"""


def run_domain_gap_experiment(source_train, target_test, model):
    """
    Would compute:
        - accuracy, macro F1, weighted F1 on target_test
        - ECE, Brier score, avg confidence, high-confidence error rate
        - Domain Gap = in-domain accuracy - target-domain accuracy
    Not executed: no real clinical `target_test` data is available.
    """
    raise NotImplementedError(
        "Real clinical target-domain data is not available in this environment. "
        "Supply real clinical records in the project's standardized schema "
        "(domain='clinical') to run this experiment."
    )


PENDING_STATUS = {
    "status": "pending",
    "reason": (
        "No real clinical text corpus is reachable from this sandbox (no network access to "
        "PhysioNet/MIMIC, Hugging Face Hub, or similar dataset hosts; MIMIC-derived data also "
        "requires credentialed access that cannot be completed in this session)."
    ),
    "what_is_ready": (
        "The full pipeline (schema, preprocessing, models, evaluation, calibration, dashboard "
        "page) is implemented and will run this experiment for real the moment a real clinical "
        "dataset is supplied in the standardized schema."
    ),
}
