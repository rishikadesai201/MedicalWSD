"""Experiment 5 - Context Sensitivity. Trains/evaluates the classical
model (fast, deterministic) across all 4 context windows to measure how
much surrounding context is needed to disambiguate."""
import numpy as np
from src.models.tfidf_logreg import TfidfLogRegWSD
from src.evaluation.metrics import compute_core_metrics

CONTEXT_FIELDS = ["context_1", "context_2", "context_3", "context_4"]
CONTEXT_LABELS = {
    "context_1": "Abbreviation only",
    "context_2": "Sentence",
    "context_3": "±1 sentence",
    "context_4": "±2 sentences",
}


def run_context_experiment(train_records, test_records):
    results = []
    for field in CONTEXT_FIELDS:
        model = TfidfLogRegWSD(context_field=field).fit(train_records)
        preds, confs, _ = model.predict(test_records)
        labels = [r["label"] for r in test_records]
        metrics = compute_core_metrics(labels, preds)
        results.append({
            "context_window": field,
            "label": CONTEXT_LABELS[field],
            "accuracy": metrics["accuracy"],
            "macro_f1": metrics["macro_f1"],
            "avg_confidence": float(np.mean(confs)),
        })
    return results


def run_perturbation_experiment(train_records, test_records):
    """Context perturbations on top of the full (±2 sentence) context:
    remove preceding context, remove following context, truncate."""
    import re

    def remove_preceding(text):
        # keep only from the sentence containing [ABBR] onward
        idx = text.find("[ABBR]")
        if idx == -1:
            return text
        # back up to the start of that sentence (previous '.')
        start = text.rfind(".", 0, idx)
        return text[start + 1:].strip() if start != -1 else text

    def remove_following(text):
        idx = text.find("[/ABBR]")
        if idx == -1:
            return text
        end = text.find(".", idx)
        return text[:end + 1].strip() if end != -1 else text

    def truncate(text, n_words=6):
        idx = text.find("[ABBR]")
        words = text.split()
        # crude truncation: take n_words on each side of the abbreviation token
        flat = " ".join(words)
        return flat[:max(len(text)//3, 40)]

    perturbations = {
        "full_context": lambda t: t,
        "remove_preceding": remove_preceding,
        "remove_following": remove_following,
        "truncate": truncate,
    }
    results = []
    for name, fn in perturbations.items():
        perturbed_train = [dict(r, context_4=fn(r["context_4"])) for r in train_records]
        perturbed_test = [dict(r, context_4=fn(r["context_4"])) for r in test_records]
        model = TfidfLogRegWSD(context_field="context_4").fit(perturbed_train)
        preds, confs, _ = model.predict(perturbed_test)
        labels = [r["label"] for r in perturbed_test]
        metrics = compute_core_metrics(labels, preds)
        results.append({
            "perturbation": name,
            "accuracy": metrics["accuracy"],
            "macro_f1": metrics["macro_f1"],
            "avg_confidence": float(np.mean(confs)),
        })
    return results
