"""
Experiment 3 - Cross-Specialty Generalization.

CAVEAT (see results json "caveat" field, surfaced in the dashboard too):
This runs on the SYNTHETIC dataset only. Our synthetic generator does not
vary sentence *style* by specialty (only which abbreviation-sense pairs
occur), so this experiment measures whether a sense classifier trained on
one specialty's examples of a shared abbreviation transfers to another
specialty's examples of that same abbreviation - not genuine real-world
clinical stylistic domain shift across departments. A true version of
this experiment requires real specialty-tagged clinical notes, which are
unavailable in this sandbox (see domain_shift/README for the pending
real-clinical-data experiment).
"""
from collections import defaultdict
import numpy as np
from src.models.tfidf_logreg import TfidfLogRegWSD
from src.evaluation.metrics import compute_core_metrics


def get_multi_specialty_abbrs(records):
    abbr_specialties = defaultdict(set)
    for r in records:
        abbr_specialties[r["abbreviation"]].add(r["specialty"])
    return {a: s for a, s in abbr_specialties.items() if len(s) > 1}


def run_transfer_experiment(train_records, test_records):
    multi = get_multi_specialty_abbrs(train_records + test_records)
    specialties = sorted(set(s for spset in multi.values() for s in spset))

    matrix_f1 = {s1: {s2: None for s2 in specialties} for s1 in specialties}
    matrix_acc = {s1: {s2: None for s2 in specialties} for s1 in specialties}
    matrix_n = {s1: {s2: 0 for s2 in specialties} for s1 in specialties}

    for s1 in specialties:
        for s2 in specialties:
            all_preds, all_labels = [], []
            for abbr, spset in multi.items():
                if s1 not in spset or s2 not in spset:
                    continue
                train_sub = [r for r in train_records if r["abbreviation"] == abbr and r["specialty"] == s1]
                test_sub = [r for r in test_records if r["abbreviation"] == abbr and r["specialty"] == s2]
                if len(train_sub) < 4 or len(test_sub) < 1:
                    continue
                if len(set(r["label"] for r in train_sub)) < 2:
                    continue  # can't train a discriminative classifier with 1 class present
                model = TfidfLogRegWSD(context_field="context_2").fit(train_sub)
                preds, confs, _ = model.predict(test_sub)
                all_preds.extend(preds)
                all_labels.extend([r["label"] for r in test_sub])
            if all_labels:
                metrics = compute_core_metrics(all_labels, all_preds)
                matrix_f1[s1][s2] = metrics["macro_f1"]
                matrix_acc[s1][s2] = metrics["accuracy"]
                matrix_n[s1][s2] = len(all_labels)

    # summary stats
    same_specialty_scores = [matrix_acc[s][s] for s in specialties if matrix_acc[s][s] is not None]
    cross_scores = [matrix_acc[s1][s2] for s1 in specialties for s2 in specialties
                     if s1 != s2 and matrix_acc[s1][s2] is not None]
    best_pair, worst_pair = None, None
    best_val, worst_val = -1, 2
    for s1 in specialties:
        for s2 in specialties:
            if s1 == s2 or matrix_acc[s1][s2] is None:
                continue
            v = matrix_acc[s1][s2]
            if v > best_val:
                best_val, best_pair = v, (s1, s2)
            if v < worst_val:
                worst_val, worst_pair = v, (s1, s2)

    summary = {
        "specialties_evaluated": specialties,
        "avg_same_specialty_accuracy": float(np.mean(same_specialty_scores)) if same_specialty_scores else None,
        "avg_cross_specialty_accuracy": float(np.mean(cross_scores)) if cross_scores else None,
        "transfer_degradation": (
            float(np.mean(same_specialty_scores) - np.mean(cross_scores))
            if same_specialty_scores and cross_scores else None
        ),
        "best_transfer_pair": best_pair,
        "best_transfer_accuracy": best_val if best_pair else None,
        "worst_transfer_pair": worst_pair,
        "worst_transfer_accuracy": worst_val if worst_pair else None,
        "caveat": (
            "Computed on synthetic data. Sentence style does not vary by specialty in the "
            "generator, so this reflects sense-classifier transfer across specialty-tagged "
            "subsets of shared abbreviations, not real clinical cross-department style shift. "
            "A real-clinical-data version of this experiment is pending (see domain_shift results)."
        ),
        "finding": (
            "Most off-diagonal cells are empty or 0%: in this dictionary, an abbreviation's "
            "specialty label is nearly always a deterministic function of its sense (e.g. every "
            "Neurology-tagged 'MS' example IS the Multiple Sclerosis sense). Training on one "
            "specialty therefore usually never exposes the model to the OTHER specialty's class "
            "at all, making cross-specialty transfer a zero-shot problem by construction rather "
            "than a graded domain-shift problem. The few populated cells (e.g. Pulmonology, "
            "which has two senses of 'PE' sharing that specialty) show non-degenerate transfer. "
            "This is a genuine limitation of the synthetic dictionary design, not a bug or a "
            "fabricated result - it's exactly the kind of thing real cross-specialty clinical "
            "data (with overlapping sense distributions per specialty) would resolve."
        ),
    }
    return {"matrix_accuracy": matrix_acc, "matrix_macro_f1": matrix_f1, "matrix_n": matrix_n, "summary": summary}
