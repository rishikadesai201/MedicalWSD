"""Evaluation metrics shared across all experiments."""
import numpy as np
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix


def compute_core_metrics(labels, preds):
    labels = list(labels)
    preds = list(preds)
    acc = accuracy_score(labels, preds)
    macro_f1 = f1_score(labels, preds, average="macro", zero_division=0)
    weighted_f1 = f1_score(labels, preds, average="weighted", zero_division=0)
    per_class_f1 = f1_score(labels, preds, average=None, zero_division=0).tolist()
    return {
        "accuracy": float(acc),
        "macro_f1": float(macro_f1),
        "weighted_f1": float(weighted_f1),
        "per_class_f1": per_class_f1,
        "n": len(labels),
    }


def per_abbreviation_performance(records, preds):
    from collections import defaultdict
    by_abbr = defaultdict(lambda: {"labels": [], "preds": []})
    for r, p in zip(records, preds):
        by_abbr[r["abbreviation"]]["labels"].append(r["label"])
        by_abbr[r["abbreviation"]]["preds"].append(p)
    out = {}
    for abbr, d in by_abbr.items():
        out[abbr] = compute_core_metrics(d["labels"], d["preds"])
    return out


def expected_calibration_error(confs, correct, n_bins=10):
    confs = np.array(confs)
    correct = np.array(correct).astype(float)
    bins = np.linspace(0, 1, n_bins + 1)
    ece = 0.0
    bin_stats = []
    for i in range(n_bins):
        lo, hi = bins[i], bins[i + 1]
        mask = (confs > lo) & (confs <= hi) if i > 0 else (confs >= lo) & (confs <= hi)
        if mask.sum() == 0:
            bin_stats.append({"bin_lo": float(lo), "bin_hi": float(hi), "count": 0,
                               "avg_conf": None, "avg_acc": None})
            continue
        avg_conf = confs[mask].mean()
        avg_acc = correct[mask].mean()
        weight = mask.sum() / len(confs)
        ece += weight * abs(avg_conf - avg_acc)
        bin_stats.append({"bin_lo": float(lo), "bin_hi": float(hi), "count": int(mask.sum()),
                           "avg_conf": float(avg_conf), "avg_acc": float(avg_acc)})
    return float(ece), bin_stats


def brier_score(prob_dists, labels, max_classes):
    total = 0.0
    for probs, label in zip(prob_dists, labels):
        p = list(probs) + [0.0] * (max_classes - len(probs))
        target = [1.0 if i == label else 0.0 for i in range(len(p))]
        total += sum((pi - ti) ** 2 for pi, ti in zip(p, target))
    return total / len(labels)


def high_confidence_error_rate(confs, correct, threshold=0.8):
    confs = np.array(confs)
    correct = np.array(correct)
    high_conf_mask = confs >= threshold
    if high_conf_mask.sum() == 0:
        return 0.0, 0
    errors = high_conf_mask & (~correct.astype(bool))
    return float(errors.sum() / high_conf_mask.sum()), int(high_conf_mask.sum())


def coverage_accuracy_curve(confs, correct, thresholds=None):
    if thresholds is None:
        thresholds = np.linspace(0.0, 0.99, 30)
    confs = np.array(confs)
    correct = np.array(correct).astype(float)
    curve = []
    for t in thresholds:
        mask = confs >= t
        coverage = mask.mean()
        retained_acc = correct[mask].mean() if mask.sum() > 0 else None
        curve.append({"threshold": float(t), "coverage": float(coverage),
                       "retained_accuracy": None if retained_acc is None else float(retained_acc),
                       "n_retained": int(mask.sum())})
    return curve
