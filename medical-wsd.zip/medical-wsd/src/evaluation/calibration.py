"""Thin wrapper so other modules can import calibration functions without
circular-importing evaluation.metrics directly (keeps experiment modules
decoupled from the exact metrics module layout)."""
from src.evaluation.metrics import (
    expected_calibration_error as expected_calibration_error_wrapper,
    brier_score,
    high_confidence_error_rate,
    coverage_accuracy_curve,
)
