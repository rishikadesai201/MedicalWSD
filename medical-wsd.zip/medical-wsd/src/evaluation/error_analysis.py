"""
Error analysis: categorizes actual model mistakes into the categories
listed in the spec (section 18). Categorization is heuristic/rule-based
(applied to REAL model predictions/errors, not fabricated), using signal
available from the dataset: number of candidate senses, abbreviation
frequency in training, confidence, and context length. This is a
transparent, reproducible heuristic - not a learned or "black box"
categorizer.
"""
from collections import Counter, defaultdict


def categorize_error(record, pred_label, confidence, train_abbr_freq, train_sense_freq):
    abbr = record["abbreviation"]
    n_candidates = record["num_candidates"]
    true_sense = record["sense"]
    pred_idx = pred_label
    candidates = record["candidate_senses"]
    pred_sense = candidates[pred_idx] if pred_idx < len(candidates) else "UNKNOWN"

    categories = []

    if confidence >= 0.8:
        categories.append("high_confidence_wrong_prediction")

    if train_abbr_freq.get(abbr, 0) < 30:
        categories.append("rare_abbreviation")

    sense_key = (abbr, true_sense)
    if train_sense_freq.get(sense_key, 0) < 10:
        categories.append("rare_sense")

    if n_candidates >= 3:
        categories.append("lexical_ambiguity")

    if record["context_2_length"] < 8:
        categories.append("insufficient_context")

    # similar candidate meanings: senses sharing specialty with the true sense
    true_specialty = record["specialty"]
    if pred_sense != true_sense:
        categories.append("specialty_specific_ambiguity" if true_specialty else "annotation_ambiguity")

    if not categories:
        categories.append("possible_annotation_ambiguity")

    return categories, pred_sense


def run_error_analysis(train_records, test_records, preds, confs):
    train_abbr_freq = Counter(r["abbreviation"] for r in train_records)
    train_sense_freq = Counter((r["abbreviation"], r["sense"]) for r in train_records)

    errors = []
    category_counts = Counter()
    for record, pred, conf in zip(test_records, preds, confs):
        if pred == record["label"]:
            continue
        cats, pred_sense = categorize_error(record, pred, conf, train_abbr_freq, train_sense_freq)
        for c in cats:
            category_counts[c] += 1
        errors.append({
            "abbreviation": record["abbreviation"],
            "context": record["context_3"],
            "predicted_sense": pred_sense,
            "actual_sense": record["sense"],
            "confidence": float(conf),
            "domain": record["domain"],
            "specialty": record["specialty"],
            "error_categories": cats,
        })
    return {
        "num_errors": len(errors),
        "num_total": len(test_records),
        "error_rate": len(errors) / len(test_records) if test_records else 0,
        "category_counts": dict(category_counts),
        "errors": errors,
    }
