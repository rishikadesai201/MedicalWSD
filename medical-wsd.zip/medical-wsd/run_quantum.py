"""
Quantum Variational Classifier experiment runner.

This script is intentionally SEPARATE from run.py. run.py's pipeline is
built around this project's synthetic generator; the quantum model must
never be trained or reported against that synthetic data, per explicit
project requirements. This script only runs once real data is available.

USAGE (once you have real data):
    1. Convert your real dataset (CASI / MeDAL / MTSamples / etc.) into
       this project's standardized schema (see src/preprocessing/pipeline.py
       for the exact fields expected: text, abbreviation, target_span,
       sense, label, domain, specialty, split, context_1..context_4,
       num_candidates, candidate_senses).
    2. Save it as data/processed/real_wsd_preprocessed.jsonl
    3. Run: PYTHONPATH=. python3 run_quantum.py

This compares the Quantum Variational Classifier against the same three
classical models from run.py (Majority, TF-IDF+LogReg, and, optionally,
the Transformer) on the SAME real data and the SAME metric suite, so the
comparison is apples-to-apples with the rest of the project's results.
"""
import json
import sys
from pathlib import Path

import numpy as np

from src.models.majority_baseline import MajorityBaseline
from src.models.tfidf_logreg import TfidfLogRegWSD
from src.models.quantum_classifier import QuantumVariationalWSD
from src.evaluation.metrics import (
    compute_core_metrics, per_abbreviation_performance,
    expected_calibration_error, brier_score, high_confidence_error_rate,
)

REAL_DATA_PATH = "data/processed/real_wsd_preprocessed.jsonl"


def load_jsonl(path):
    return [json.loads(l) for l in open(path)]


def evaluate(name, model, test, max_classes):
    preds, confs, prob_dists = model.predict(test)
    labels = [r["label"] for r in test]
    correct = [p == l for p, l in zip(preds, labels)]
    core = compute_core_metrics(labels, preds)
    ece, _ = expected_calibration_error(confs, correct)
    brier = brier_score(prob_dists, labels, max_classes)
    hce_rate, hce_n = high_confidence_error_rate(confs, correct, threshold=0.8)
    result = {
        "model": name, **core, "ece": ece, "brier_score": brier,
        "avg_confidence": float(np.mean(confs)),
        "high_confidence_error_rate": hce_rate, "high_confidence_n": hce_n,
    }
    Path("results/metrics").mkdir(parents=True, exist_ok=True)
    with open(f"results/metrics/{name}_REAL_test_metrics.json", "w") as f:
        json.dump(result, f, indent=2)
    return result


def main():
    if not Path(REAL_DATA_PATH).exists():
        print("=" * 70)
        print("NO REAL DATA FOUND.")
        print("=" * 70)
        print(f"Expected file not found: {REAL_DATA_PATH}")
        print()
        print("This script deliberately will NOT fall back to the synthetic")
        print("generator -- the quantum model must only be trained/reported")
        print("on real data, per project requirements.")
        print()
        print("To proceed:")
        print("  1. Obtain a real dataset (CASI is the fastest: no application")
        print("     required, download at conservancy.umn.edu/handle/11299/137703).")
        print("  2. Convert it into this project's standardized schema (see")
        print("     src/preprocessing/pipeline.py for the exact fields).")
        print(f"  3. Save the result as {REAL_DATA_PATH}")
        print("  4. Re-run this script.")
        sys.exit(1)

    records = load_jsonl(REAL_DATA_PATH)
    train = [r for r in records if r["split"] == "train"]
    test = [r for r in records if r["split"] == "test"]
    max_classes = max(r["num_candidates"] for r in records)
    print(f"Loaded {len(records)} REAL records ({len(train)} train / {len(test)} test).")

    print("\nTraining Majority baseline...")
    m1 = MajorityBaseline().fit(train)
    r1 = evaluate("majority_baseline", m1, test, max_classes)
    print(f"  acc={r1['accuracy']:.3f}  macroF1={r1['macro_f1']:.3f}")

    print("\nTraining TF-IDF + Logistic Regression...")
    m2 = TfidfLogRegWSD(context_field="context_2").fit(train)
    r2 = evaluate("tfidf_logreg", m2, test, max_classes)
    print(f"  acc={r2['accuracy']:.3f}  macroF1={r2['macro_f1']:.3f}")

    print("\nTraining Quantum Variational Classifier (simulated, exploratory)...")
    m4 = QuantumVariationalWSD(context_field="context_2", n_qubits=6, n_layers=3, epochs=60, lr=0.15)
    m4.fit(train, verbose=True)
    r4 = evaluate("quantum_variational", m4, test, max_classes)
    print(f"  acc={r4['accuracy']:.3f}  macroF1={r4['macro_f1']:.3f}")

    print("\n" + "=" * 70)
    print("Summary (real data):")
    for r in [r1, r2, r4]:
        print(f"  {r['model']:24s} acc={r['accuracy']:.3f}  macroF1={r['macro_f1']:.3f}  ECE={r['ece']:.3f}")
    print("=" * 70)


if __name__ == "__main__":
    main()
