import json
import pickle
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import streamlit as st
import plotly.express as px
import plotly.graph_objects as go

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.models.live_inference import run_live_wsd, detect_abbreviations
from src.data.abbreviation_dictionary import ABBREVIATION_DICT

st.set_page_config(page_title="Cross-Specialty Medical Abbreviation WSD", layout="wide",
                    initial_sidebar_state="expanded")

LIGHT_CSS = """
<style>
.stApp { background-color: #fafafa; }
[data-testid="stSidebar"] { background-color: #f0f2f6; }
h1, h2, h3 { color: #1a2b4c; }
.metric-card {
    background: white; border-radius: 10px; padding: 1rem 1.2rem;
    border: 1px solid #e5e7eb; box-shadow: 0 1px 2px rgba(0,0,0,0.04);
}
.pending-badge {
    display:inline-block; background:#fdecea; color:#a94442; border:1px solid #f5c6cb;
    border-radius:6px; padding:2px 10px; font-size:0.8rem; font-weight:600;
}
.synthetic-badge {
    display:inline-block; background:#eef4ff; color:#2952a3; border:1px solid #c9dcff;
    border-radius:6px; padding:2px 10px; font-size:0.8rem; font-weight:600;
}
</style>
"""
st.markdown(LIGHT_CSS, unsafe_allow_html=True)


@st.cache_data
def load_json(path):
    p = ROOT / path
    if not p.exists():
        return None
    return json.load(open(p))


@st.cache_data
def load_jsonl(path):
    p = ROOT / path
    if not p.exists():
        return []
    return [json.loads(l) for l in open(p)]


@st.cache_resource
def load_model(path):
    p = ROOT / path
    with open(p, "rb") as f:
        return pickle.load(f)


PAGES = ["Overview", "Live WSD", "Model Comparison", "Domain Generalization",
         "Cross-Specialty", "Data Efficiency", "Context Analysis", "Confidence", "Error Analysis"]

st.sidebar.title("Medical Abbreviation WSD")
st.sidebar.caption("Cross-Specialty Generalization Research Dashboard")
page = st.sidebar.radio("Navigate", PAGES, label_visibility="collapsed")
st.sidebar.markdown("---")
st.sidebar.markdown(
    "<span class='synthetic-badge'>SYNTHETIC DATA</span>",
    unsafe_allow_html=True,
)
st.sidebar.caption(
    "All results on this dashboard (unless marked PENDING) are computed on a "
    "template-generated synthetic dataset - a stand-in for MeDAL/PubMed-style text, "
    "since Hugging Face Hub / MIMIC are unreachable from this sandbox. No real patient "
    "data is used anywhere in this project."
)

# ---------------------------------------------------------------- OVERVIEW
if page == "Overview":
    st.title("Cross-Specialty Medical Abbreviation WSD")
    st.subheader("Bridging Synthetic and Real Clinical Text")

    eda = load_json("results/metrics/eda_stats.json")
    comparison = load_json("results/metrics/model_comparison.json")

    if eda and comparison:
        best_model = max(comparison["models"], key=lambda m: m["macro_f1"])
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Dataset size", eda["total_samples"])
        c2.metric("Abbreviations", eda["unique_abbreviations"])
        c3.metric("Senses", eda["unique_senses"])
        c4.metric("Best model Macro F1", f"{best_model['macro_f1']:.3f}", help=best_model["model"])

    st.markdown("### Research Pipeline")
    st.markdown(
        "`Medical Text` → `Abbreviation Detection` → `Context Extraction` → "
        "`Candidate Sense ID` → `WSD Prediction` → `Confidence` → `Calibration` → "
        "`Domain / Specialty Analysis`"
    )

    st.markdown("### What's real vs. pending in this build")
    colA, colB = st.columns(2)
    with colA:
        st.markdown("**Fully implemented & run on real experiments (synthetic data):**")
        st.markdown(
            "- Data generation, EDA, preprocessing, leakage check\n"
            "- 3 models: Majority, TF-IDF+LogReg, Small Transformer (trained from scratch)\n"
            "- In-domain evaluation, per-abbreviation performance, confusion matrices\n"
            "- Calibration: ECE, Brier score, reliability diagrams, high-confidence errors\n"
            "- Uncertainty / abstention (coverage vs. accuracy)\n"
            "- Context sensitivity across 4 context windows + perturbations\n"
            "- Cross-specialty transfer matrix (synthetic, with documented limitation)\n"
            "- Data-efficient adaptation curve (proxy target domain)\n"
            "- Rule-based error categorization + interactive error explorer\n"
            "- Live WSD inference demo"
        )
    with colB:
        st.markdown("**Marked pending (needs unreachable resources):**")
        st.markdown(
            "<span class='pending-badge'>PENDING</span> Synthetic/PubMed → real clinical "
            "domain-gap experiment — needs a real de-identified clinical corpus "
            "(e.g. MIMIC), which requires credentialed access unavailable in this sandbox.",
            unsafe_allow_html=True,
        )
        st.markdown(
            "<span class='pending-badge'>SUBSTITUTED</span> 'Biomedical transformer' "
            "(PubMedBERT/BioBERT/etc.) — those weights live on Hugging Face Hub, which "
            "this sandbox cannot reach. A small Transformer trained from scratch on our "
            "synthetic data is used instead, and labeled as such everywhere.",
            unsafe_allow_html=True,
        )
    st.caption("See the README for the full list of network/data constraints and how to unblock the pending items.")

# ---------------------------------------------------------------- LIVE WSD
elif page == "Live WSD":
    st.title("Live WSD Inference")
    st.caption("Uses the trained TF-IDF + Logistic Regression model (loaded from disk, not retrained).")

    example = "Patient with CHF presents with dyspnea and reduced ejection fraction."
    text = st.text_area("Enter clinical text", value=example, height=100)
    threshold = st.slider("Uncertainty threshold (below this confidence → flagged for human review)",
                           0.0, 1.0, 0.5, 0.05)

    if text.strip():
        model = load_model("models/tfidf_logreg.pkl")
        results = run_live_wsd(text, model, uncertainty_threshold=threshold)
        if not results:
            st.info("No known abbreviations detected in this text. Try one of: " +
                     ", ".join(list(ABBREVIATION_DICT.keys())[:10]) + " ...")
        for r in results:
            with st.container(border=True):
                c1, c2 = st.columns([1, 2])
                with c1:
                    st.markdown(f"#### Detected: `{r['abbreviation']}`")
                    if r["is_uncertain"]:
                        st.warning(f"⚠️ UNCERTAIN — HUMAN REVIEW  (confidence {r['confidence']*100:.1f}%)")
                    else:
                        st.success(f"**{r['raw_predicted_sense']}**")
                        st.metric("Confidence", f"{r['confidence']*100:.1f}%")
                with c2:
                    st.markdown("**Candidate meanings**")
                    for sense, prob in sorted(r["candidate_senses"], key=lambda x: -x[1]):
                        st.progress(prob, text=f"{sense} — {prob*100:.1f}%")
                    if r["context_signals"]:
                        st.markdown("**Context signals found in text**")
                        for sense, hits in r["context_signals"].items():
                            st.caption(f"→ *{sense}*: " + ", ".join(hits))

# ---------------------------------------------------------------- MODEL COMPARISON
elif page == "Model Comparison":
    st.title("Model Comparison")
    comparison = load_json("results/metrics/model_comparison.json")
    if comparison:
        df = pd.DataFrame(comparison["models"])
        df_display = df[["model", "accuracy", "macro_f1", "weighted_f1", "ece", "brier_score"]].round(3)
        st.dataframe(df_display, use_container_width=True, hide_index=True)

        fig = go.Figure()
        for metric in ["accuracy", "macro_f1", "weighted_f1"]:
            fig.add_trace(go.Bar(name=metric, x=df["model"], y=df[metric]))
        fig.update_layout(barmode="group", yaxis_range=[0, 1], title="Accuracy / Macro F1 / Weighted F1")
        st.plotly_chart(fig, use_container_width=True)

        st.caption(
            "**Majority**: predicts the most frequent training sense per abbreviation. "
            "**TF-IDF+LogReg**: classical bag-of-ngrams classifier, one per abbreviation. "
            "**Small Transformer (Scratch)**: a small self-attention model trained only on "
            "this project's synthetic data — not a pretrained biomedical LM (see Overview)."
        )

# ---------------------------------------------------------------- DOMAIN GENERALIZATION
elif page == "Domain Generalization":
    st.title("Domain Generalization: Synthetic → Real Clinical")
    pending = load_json("results/domain_shift/synthetic_to_clinical_PENDING.json")
    st.markdown("<span class='pending-badge'>PENDING — real clinical data unavailable</span>", unsafe_allow_html=True)
    if pending:
        st.markdown(f"**Reason:** {pending['reason']}")
        st.markdown(f"**What's ready:** {pending['what_is_ready']}")
    st.markdown("---")
    st.markdown("#### What would render here with real clinical data")
    st.markdown(
        "- Accuracy / Macro F1 / Weighted F1 on real clinical text\n"
        "- ECE, Brier score, average confidence, high-confidence error rate on target domain\n"
        "- **Domain Gap** = in-domain accuracy − target-domain accuracy, visualized as a bar chart"
    )
    comparison = load_json("results/metrics/model_comparison.json")
    if comparison:
        st.markdown("#### Available now: in-domain (synthetic) baseline these numbers would be compared against")
        df = pd.DataFrame(comparison["models"])[["model", "accuracy", "macro_f1", "ece"]]
        st.dataframe(df.round(3), use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- CROSS-SPECIALTY
elif page == "Cross-Specialty":
    st.title("Cross-Specialty Generalization")
    st.markdown("<span class='synthetic-badge'>SYNTHETIC DATA</span>", unsafe_allow_html=True)
    data = load_json("results/specialty_transfer/cross_specialty_results.json")
    if data:
        specialties = data["summary"]["specialties_evaluated"]
        mat = data["matrix_accuracy"]
        z = [[mat[s1][s2] if mat[s1][s2] is not None else None for s2 in specialties] for s1 in specialties]
        fig = px.imshow(z, x=specialties, y=specialties, color_continuous_scale="RdYlGn",
                         zmin=0, zmax=1, text_auto=".2f", aspect="auto",
                         labels=dict(x="Test specialty", y="Train specialty", color="Accuracy"))
        fig.update_layout(title="Specialty Transfer Matrix (Accuracy)")
        st.plotly_chart(fig, use_container_width=True)

        c1, c2, c3 = st.columns(3)
        s = data["summary"]
        c1.metric("Avg same-specialty acc", f"{s['avg_same_specialty_accuracy']:.2f}" if s["avg_same_specialty_accuracy"] else "N/A")
        c2.metric("Avg cross-specialty acc", f"{s['avg_cross_specialty_accuracy']:.2f}" if s["avg_cross_specialty_accuracy"] is not None else "N/A")
        c3.metric("Transfer degradation", f"{s['transfer_degradation']:.2f}" if s["transfer_degradation"] is not None else "N/A")

        st.info(f"**Caveat:** {s['caveat']}")
        st.warning(f"**Finding:** {s['finding']}")

# ---------------------------------------------------------------- DATA EFFICIENCY
elif page == "Data Efficiency":
    st.title("Data-Efficient Adaptation")
    st.markdown("<span class='synthetic-badge'>SYNTHETIC DATA — proxy target domain</span>", unsafe_allow_html=True)
    data = load_json("results/data_efficiency/neurology_proxy_target.json")
    if data and "results" in data and data["results"]:
        st.caption(data["caveat"])
        df = pd.DataFrame(data["results"])
        df["target_data_percentage"] *= 100
        fig1 = px.line(df, x="target_data_percentage", y=["accuracy", "macro_f1"], markers=True,
                        labels={"target_data_percentage": "Target-domain data used (%)", "value": "Score"},
                        title=f"Performance vs Target Data ({data['target_specialty']})")
        fig2 = px.line(df, x="target_data_percentage", y="ece", markers=True,
                        labels={"target_data_percentage": "Target-domain data used (%)", "ece": "ECE"},
                        title="Calibration (ECE) vs Target Data")
        c1, c2 = st.columns(2)
        c1.plotly_chart(fig1, use_container_width=True)
        c2.plotly_chart(fig2, use_container_width=True)
        st.dataframe(df.round(3), use_container_width=True, hide_index=True)

# ---------------------------------------------------------------- CONTEXT ANALYSIS
elif page == "Context Analysis":
    st.title("Context Sensitivity")
    ctx = load_json("results/context_analysis/context_sensitivity.json")
    perturb = load_json("results/context_analysis/perturbation_results.json")
    if ctx:
        df = pd.DataFrame(ctx)
        fig = px.line(df, x="label", y=["accuracy", "avg_confidence"], markers=True,
                       labels={"label": "Context window", "value": "Score"},
                       title="Accuracy & Confidence vs. Context Window")
        st.plotly_chart(fig, use_container_width=True)
        st.dataframe(df.round(3), use_container_width=True, hide_index=True)
    if perturb:
        st.markdown("### Context Perturbations (on ±2-sentence window)")
        dfp = pd.DataFrame(perturb)
        fig2 = px.bar(dfp, x="perturbation", y="accuracy", title="Accuracy under Context Perturbation")
        st.plotly_chart(fig2, use_container_width=True)

    st.markdown("### Explore an example")
    test_preds = load_jsonl("results/predictions/tfidf_logreg_predictions.jsonl")
    if test_preds:
        abbrs = sorted(set(p["abbreviation"] for p in test_preds))
        chosen = st.selectbox("Abbreviation", abbrs)
        examples = [p for p in test_preds if p["abbreviation"] == chosen][:3]
        for ex in examples:
            st.write(f"**Context:** {ex['context_3']}")
            st.write(f"Predicted: `{ex['predicted_sense']}`  |  Actual: `{ex['true_sense']}`  |  "
                     f"Confidence: {ex['confidence']*100:.1f}%  |  {'✅' if ex['correct'] else '❌'}")
            st.markdown("---")

# ---------------------------------------------------------------- CONFIDENCE
elif page == "Confidence":
    st.title("Confidence Calibration")
    model_choice = st.selectbox("Model", ["small_transformer_scratch", "tfidf_logreg", "majority_baseline"])
    reliability = load_json(f"results/calibration/{model_choice}_reliability.json")
    coverage = load_json(f"results/calibration/{model_choice}_coverage_accuracy.json")
    metrics = load_json(f"results/metrics/{model_choice}_test_metrics.json")

    if metrics:
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("ECE", f"{metrics['ece']:.3f}")
        c2.metric("Brier Score", f"{metrics['brier_score']:.3f}")
        c3.metric("Avg Confidence", f"{metrics['avg_confidence']:.3f}")
        c4.metric("High-Conf Error Rate (≥0.8)", f"{metrics['high_confidence_error_rate']*100:.1f}%")

    if reliability:
        bins = [b for b in reliability["bins"] if b["count"] > 0]
        dfb = pd.DataFrame(bins)
        fig = go.Figure()
        fig.add_trace(go.Bar(x=(dfb["bin_lo"] + dfb["bin_hi"]) / 2, y=dfb["avg_acc"], name="Accuracy", width=0.08))
        fig.add_trace(go.Scatter(x=[0, 1], y=[0, 1], mode="lines", name="Perfect calibration", line=dict(dash="dash")))
        fig.update_layout(title="Reliability Diagram", xaxis_title="Confidence bin", yaxis_title="Accuracy")
        st.plotly_chart(fig, use_container_width=True)

    if coverage:
        dfc = pd.DataFrame(coverage)
        fig2 = px.line(dfc, x="coverage", y="retained_accuracy", title="Coverage vs. Accuracy (Abstention)",
                        labels={"coverage": "Coverage (fraction retained)", "retained_accuracy": "Retained Accuracy"})
        st.plotly_chart(fig2, use_container_width=True)
        st.caption(
            "This curve shows what happens if the model abstains ('UNCERTAIN — HUMAN REVIEW') "
            "on low-confidence predictions: as coverage drops, retained accuracy should rise if "
            "confidence is trustworthy."
        )

# ---------------------------------------------------------------- ERROR ANALYSIS
elif page == "Error Analysis":
    st.title("Error Analysis")
    err = load_json("results/errors/error_analysis.json")
    if err:
        c1, c2 = st.columns(2)
        c1.metric("Total errors", err["num_errors"])
        c2.metric("Error rate", f"{err['error_rate']*100:.1f}%")

        cat_df = pd.DataFrame(list(err["category_counts"].items()), columns=["category", "count"]).sort_values("count", ascending=False)
        fig = px.bar(cat_df, x="count", y="category", orientation="h", title="Error Category Distribution")
        st.plotly_chart(fig, use_container_width=True)

        st.markdown("### High-Confidence Error Explorer")
        errors_df = pd.DataFrame(err["errors"])
        if not errors_df.empty:
            colf1, colf2, colf3 = st.columns(3)
            abbr_filter = colf1.multiselect("Abbreviation", sorted(errors_df["abbreviation"].unique()))
            specialty_filter = colf2.multiselect("Specialty", sorted(errors_df["specialty"].unique()))
            min_conf = colf3.slider("Min confidence", 0.0, 1.0, 0.0, 0.05)

            filtered = errors_df.copy()
            if abbr_filter:
                filtered = filtered[filtered["abbreviation"].isin(abbr_filter)]
            if specialty_filter:
                filtered = filtered[filtered["specialty"].isin(specialty_filter)]
            filtered = filtered[filtered["confidence"] >= min_conf]

            st.caption(f"Showing {len(filtered)} of {len(errors_df)} errors")
            for _, row in filtered.head(25).iterrows():
                with st.container(border=True):
                    st.markdown(f"**Abbreviation:** `{row['abbreviation']}`  |  **Specialty:** {row['specialty']}  |  **Confidence:** {row['confidence']*100:.1f}%")
                    st.write(f"**Context:** {row['context']}")
                    cA, cB = st.columns(2)
                    cA.error(f"Predicted: {row['predicted_sense']}")
                    cB.success(f"Actual: {row['actual_sense']}")
                    st.caption("Error types: " + ", ".join(row["error_categories"]))
